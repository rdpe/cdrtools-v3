/* @(#)auheader.h	1.2 98/05/09 Copyright 1998 J. Schilling */
/*
 *	Copyright (c) 1998 J. Schilling
 */
/*
 * The contents of this file are subject to the terms of the
 * Common Development and Distribution License, Version 1.0 only
 * (the "License").  You may not use this file except in compliance
 * with the License.
 *
 * See the file CDDL.Schily.txt in this distribution for details.
 *
 * When distributing Covered Code, include this CDDL HEADER in each
 * file and include the License file CDDL.Schily.txt from this distribution.
 */

#ifndef	_AUHEADER_H
#define	_AUHEADER_H

#define	AU_BAD		-1
#define	AU_BAD_HEADER	-2
#define	AU_BAD_CODING	-3


#endif	/* _AUHEADER_H */
