/* @(#)version.h	1.86 15/08/26 Copyright 2007-2015 J. Schilling */

/*
 * The version for cdrtools programs
 */
#define	VERSION	"3.01"
