/* @(#)ioctl.h	1.3 12/12/02 Copyright 1998,1999 Heiko Eissfeldt */
void SetupCookedIoctl __PR((char *pdev_name));
