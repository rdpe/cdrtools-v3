/*****************************************************************************\
* bldlevel.h :: OS/2 BLDLEVEL Information                                     *
* --------------------------------------------------------------------------- *
* This file contains the generic BLDLEVEL information for OS/2.               *
* Specific strings for executables are embedded in their main source.         *
* When 'VENDOR_BUILD' is defined, 'BLDLVL_VENDOR' and 'BLDLVL_MACHINE' are    *
* set to vendor specific values. Otherwise they are set to '*UNKNOWN*'.       *
* Source commits are always done with 'VENDOR_BUILD' undefined, as a means to *
* distinguish personal builds from vendor builds. You are kindly requested    *
* not to distribute binaries with the vendor set to 'RDPe'.                   *
\*****************************************************************************/

#ifdef  __cplusplus
extern  "C" {
#endif


/* When enabled, vendor-build is forced and release timestamps are used */
//~ #define         RELEASE_BUILD

/* When enabled, vendor specific info is embedded */
#define         VENDOR_BUILD

/* A release-build implies a vendor-build */
#ifdef  RELEASE_BUILD
#define         VENDOR_BUILD
#endif

/* Vendor Information */
#ifdef  VENDOR_BUILD
#define         BLDLVL_VENDOR           "RDPe"
#else
#define         BLDLVL_VENDOR           "*UNKNOWN*"
#endif

/* Version Information */
#define         BLDLVL_MAJOR_VERSION    "3"
#define         BLDLVL_MIDDLE_VERSION   "0"
#define         BLDLVL_MINOR_VERSION    "1"

/* Build Date */
#define         BLDLVL_YEAR             "2017"
#define         BLDLVL_MONTH            "04"
#define         BLDLVL_DAY              "03"

/* Build Time -- 00:00:00 indicates a release-build, 23:59:59 a test-build */
#ifdef  RELEASE_BUILD
#define         BLDLVL_HOURS            "00"
#define         BLDLVL_MINUTES          "00"
#define         BLDLVL_SECONDS          "00"
#else
#define         BLDLVL_HOURS            "23"
#define         BLDLVL_MINUTES          "59"
#define         BLDLVL_SECONDS          "59"
#endif

/* Name of the Build Machine */
#ifdef  VENDOR_BUILD
#define         BLDLVL_MACHINE          "OS2BLDBOX"
#else
#define         BLDLVL_MACHINE          "*UNKNOWN*"
#endif

/* Language for this build */
#define         BLDLVL_LANGUAGE         "EN"


#ifdef  __cplusplus
};
#endif
