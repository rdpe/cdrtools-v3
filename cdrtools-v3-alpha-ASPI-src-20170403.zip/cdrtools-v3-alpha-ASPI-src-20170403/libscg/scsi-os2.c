/* @(#)scsi-os2.c	1.26 06/11/26 Copyright 1998 J. Schilling, C. Wohlgemuth */
#ifndef lint
static	char __sccsid[] =
	"@(#)scsi-os2.c	1.26 06/11/26 Copyright 1998 J. Schilling, C. Wohlgemuth";
#endif
/*
 *	Interface for the OS/2 ASPI-Router ASPIROUT.SYS ((c) D. Dorau).
 *		This additional driver is a prerequisite for using cdrecord.
 *		Get it from HOBBES or LEO.
 *
 *	Warning: you may change this source, but if you do that
 *	you need to change the _scg_version and _scg_auth* string below.
 *	You may not return "schily" for an SCG_AUTHOR request anymore.
 *	Choose your name instead of "schily" and make clear that the version
 *	string is related to a modified source.
 *
 *	XXX it currently uses static SRB and for this reason is not reentrant
 *
 *	Copyright (c) 1998 J. Schilling
 *	Copyright (c) 1998 C. Wohlgemuth for this interface.
 */
/*
 * The contents of this file are subject to the terms of the
 * Common Development and Distribution License, Version 1.0 only
 * (the "License").  You may not use this file except in compliance
 * with the License.
 *
 * See the file CDDL.Schily.txt in this distribution for details.
 *
 * The following exceptions apply:
 * CDDL �3.6 needs to be replaced by: "You may create a Larger Work by
 * combining Covered Software with other code if all other code is governed by
 * the terms of a license that is OSI approved (see www.opensource.org) and
 * you may distribute the Larger Work as a single product. In such a case,
 * You must make sure the requirements of this License are fulfilled for
 * the Covered Software."
 *
 * When distributing Covered Code, include this CDDL HEADER in each
 * file and include the License file CDDL.Schily.txt from this distribution.
 */

#undef	sense

#define  INCL_DOSERRORS
#define  INCL_DOSPROCESS
#define  INCL_DOSDEVICES
#define  INCL_DOSDEVIOCTL
#define  INCL_DOSSEMAPHORES
#include <os2safe.h>
#include <os2.h>

/*#define	DEBUG*/

/* For AspiRouter */
#include "scg/srb_os2.h"

/* OS/2 BLDLEVEL Information */
#include <i386-os2-gcc/bldlevel.h>

/*
 *	Warning: you may change this source, but if you do that
 *	you need to change the _scg_version and _scg_auth* string below.
 *	You may not return "schily" for an SCG_AUTHOR request anymore.
 *	Choose your name instead of "schily" and make clear that the version
 *	string is related to a modified source.
 */
LOCAL	char	_scg_auth_rdpe[]	= "rdpe";	/* The author for this module	*/
LOCAL	char	_scg_trans_version[] = "scsi-os2.c-1.26";	/* The version for this transport*/

#define	FILE_OPEN			0x0001
#define	OPEN_SHARE_DENYREADWRITE	0x0010
#define	OPEN_ACCESS_READWRITE		0x0002
#define	DC_SEM_SHARED			0x01
#define	OBJ_TILE			0x0040
#define	PAG_READ			0x0001
#define	PAG_WRITE			0x0002
#define	PAG_COMMIT			0x0010

typedef unsigned long LHANDLE;
typedef unsigned long ULONG;
typedef unsigned char *PSZ;
typedef unsigned short USHORT;
typedef unsigned char UCHAR;

typedef LHANDLE	HFILE;
typedef ULONG	HEV;

#define	MAX_SCG		16	/* Max # of SCSI controllers */
#define	MAX_TGT		16
#define	MAX_LUN		8

struct scg_local {
	int	dummy;
};
#define	scglocal(p)	((struct scg_local *)((p)->local))

#define	MAX_DMA_OS2	(63*1024) /* ASPI-Router allows up to 64k */

LOCAL	void	*buffer		= NULL;
LOCAL	HFILE	driver_handle	= 0;
LOCAL	HEV	postSema	= 0;

LOCAL	BOOL	open_driver	__PR((SCSI *scgp));
LOCAL	BOOL	close_driver	__PR((void));
LOCAL	ULONG	wait_post	__PR((ULONG ulTimeOut));
LOCAL	BOOL 	init_buffer	__PR((void* mem));
LOCAL	void	exit_func	__PR((void));
LOCAL	void	set_error	__PR((SRB *srb, struct scg_cmd *sp));

/*
// This flag is used to select between ASPI or DMD.
// This involves the drivers 'aspirout.sys' and 'os2cdrom.dmd' with the
// respective drivernames 'aspirou$' and 'cd-rom2$'.
// It is initialized in scgo_open(), based on the existence and value of an
// environment variable called 'LIBSCG_USE_ASPI'. If it exists and has the
// value '1', then ASPI is used, otherwise DMD is used.
// So, DMD is used by default, unless overridden by this method.
*/
BOOL	bUseAspi;		// Initialized in scgo_open()

/*
// This flag is used to output debug-info for 'libscg'.
// It is initialized in scgo_open(), based on the existence and value of an
// environment variable called 'LIBSCG_DEBUG'. If it exists and has the
// value '1', then debug-info is enabled.
*/
BOOL	bLibscgDebug;	// Initialized in scgo_open()

/* show function invocations */
BOOL	bShowFunc = TRUE;	// RDPe
//~ LOCAL	BOOL	bShowFunc = FALSE;	// RDPe

/* pointer to the name of the driver to open */
PSZ		drivername = NULL;

//~ #include "scsi-os2-dmd.c"

/*
// Category    : IOCTL_CDROMDISK2 (82h)
// Function    : CDROMDISK2_DRIVELETTERS (60h)
// Description : Returns drive letters for CD-ROM devices that are controlled by
//               "CD-ROM2$" device name.
*/
struct DriveLetters {
	USHORT		DriveCount;				// number of supported CD-ROM drives
	USHORT		DriveFirst;				// index of the first CD-ROM drive (A=0)
};

/*
// Category    : IOCTL_CDROMDISK (80h)
// Function    : CDROMDISK_EXECMD (7Ah)
// Description : Executes SCSI command.
*/
struct ExecCMD {
	ULONG		ID_code;				// 'CD01'
	USHORT		data_length;			// length of the Data Packet
	USHORT		cmd_length;				// length of the Command Buffer
	USHORT		flags;					// flags
	UCHAR		cmd_buffer[16];			// Command Buffer for SCSI command
	ULONG		cmd_timeout;			// Timeout for executing command (0 - default)
};

/*
// Category    : IOCTL_CDROMDISK2 (82h)
// Function    : CDROMDISK_EXECMD (7Ah)
// Description : Executes SCSI command.
*/
struct ExecCMD2 {
	UCHAR		unit;					// unit number: 0 for A:, 1 for B:, etc.
	USHORT		data_length;			// length of the Data Packet
	USHORT		cmd_length;				// length of the Command Buffer
	USHORT		flags;					// flags
	UCHAR		cmd_buffer[16];			// Command Buffer for SCSI command
	ULONG		cmd_timeout;			// Timeout for executing command (0 - default)
};

/*
// Category    : IOCTL_CDROMDISK (80h) and IOCTL_CDROMDISK (82h)
// Function    : CDROMDISK_EXECMD (7Ah)
// Description : Executes SCSI command.
*/
struct RetStatus {
	UCHAR		sense_key;				// Sense Key
	UCHAR		asc_code;				// Additional Sense Code (ASC)
	UCHAR		ascq_code;				// Additional Sense Code Qualifier (ASCQ)
};

/*
// Store info for drives.
// Note that 'locked' indicates 'dasd' locks while 'lock_state' indicates
// 'tray' locks and ioctl support flags. Also note the 'devstat_ex' status,
// which is addressable as a UNLONG as well as individual bits.
*/
struct DRIVE {
	CHAR	index;							// index, 0=A
	CHAR	letter;							// the actual ASCII letter
	HFILE	handle;							// handle when DASD opened, otherwise -1
	union {
		ULONG	flags;
		struct {
			ULONG	locked			:1;		// 1=locked, 0=unlocked (DASD)
			ULONG	reset_done		:1;		// if drive has been reset and media redetermined
			ULONG	reserved_00		:30;	// reserved bits
		};
	};
	union {
		ULONG	traystat_ex;				// tray status as ulong
		struct {
			ULONG	lockstat		:2;		// 0=nfns, 1=locked, 2=unlocked, 3=nlss
			ULONG	media_present	:1;		// 1=present, 0=absent
			ULONG	reserved_01		:29;	// reserved
		};
	};
	ULONG	blank_status;					// percentage blanked if supported
	union {
		ULONG	devstat_ex;					// extended device status as ulong
		struct {
			ULONG	tray_open		:1;		// 1=open, 0=closed
			ULONG	disc_present	:1;		// 1=present, 0=absent
			ULONG	ready_state		:2;		// 0=not ready, 1=becoming ready, 2=busy, 3=ready
			ULONG	interface		:3;		// 0=unknown, 1=scsi, 2=atapi, 3=proprietary, 4=usb
			ULONG	reserved_02		:25;	// reserved bits
		};
	};
};

/*
// Structure to contain information about the 'os2cdrom.dmd' driver.
// It's good to have this all in one place instead of multiple module globals.
// Note that the feature flags are addressable as a UNLONG and as individual
// bits using a union. The ULONG addressed as bits needs to be encapsulated
// in a struct or otherwise the union semantics would be applied to the
// bits too, overlaying them all to the LSB.
*/
struct OS2CDROMDMD {
	HFILE	handle;				// handle for the driver, -1 otherwise
	union {
		ULONG	features;		// features supported as ulong
		struct {
			ULONG	usb_support			:1;		// supports usb devices
			ULONG	cdrw_support		:1;		// supports cdrw discs
			ULONG	scsi_support		:1;		// supports scsi commands
			ULONG	ddcdrw_support		:1;		// ??
			ULONG	dvdrw_support		:1;		// supports dvd-rw discs
			ULONG	dvdrwplus_support	:1;		// supports dvd+rw discs
			ULONG	caching_support		:1;		// supports caching
			ULONG	rwdata_support		:1;		// supports writing pf rw disks
			ULONG	scsireterr_support	:1;		// supports scsi return codes
			ULONG	reserved			:23;	// reserved bits
		};
	};
	UCHAR	first_drive;		// numeric index of first handled drive (0=A)
	UCHAR	drive_count;		// number of drives handled by 'os2cdrom.dmd'
	struct DRIVE drives[26];	// storage for drive information for drives A-Z
	UCHAR	*buffer;			// pointer to result buffer
	ULONG	bufsize;			// size of buffer
};

/*
// Storage for the driver information and state.
// This is used by DosDevIOCtl calls, whether they are specifically against
// the 'os2cdrom.dmd' driver or more generic calls.
*/
struct OS2CDROMDMD	os2cdromdmd;


/* DMD Functions */
APIRET	dmd_open(struct OS2CDROMDMD *os2cdromdmd);
APIRET	dmd_init(struct OS2CDROMDMD *os2cdromdmd);
APIRET	dmd_close(struct OS2CDROMDMD *os2cdromdmd);
APIRET	dmd_query_drives(struct OS2CDROMDMD *os2cdromdmd);
APIRET	dmd_query_features(struct OS2CDROMDMD *os2cdromdmd);

/* Drive Functions */
APIRET	dmd_drive_open(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter);
APIRET	dmd_drive_lock(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter);
APIRET	dmd_drive_unlock(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter);
APIRET	dmd_drive_close(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter);
APIRET	dmd_drive_redetermine_media(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter);

/* SCSI Functions */
APIRET	dmd_drive_scsi_exec(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter, UCHAR *cmd_buf, ULONG cmd_len, UCHAR *result_buf, ULONG result_len, UCHAR *sense_buf, ULONG sense_len);
APIRET	dmd_drive_scsi_exec2(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter, UCHAR *cmd_buf, ULONG cmd_len, UCHAR *result_buf, ULONG result_len, UCHAR *sense_buf, ULONG sense_len);
APIRET	dmd_drive_scsi_process_srb(struct OS2CDROMDMD *os2cdromdmd, SRB *srb, ULONG srb_len);

/* Media Functions */
APIRET	dmd_drive_media_lock(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter);
APIRET	dmd_drive_media_get_lock_status(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter);
APIRET	dmd_drive_media_unlock(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter);
APIRET	dmd_drive_media_eject(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter);
APIRET	dmd_drive_media_blank(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter);
APIRET	dmd_drive_media_blank_full(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter);
APIRET	dmd_drive_media_blank_cancel(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter);
APIRET	dmd_drive_media_get_blank_status(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter);

/* Extended Functions */
APIRET	dmd_drive_format_verify(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter);
APIRET	dmd_drive_flush_buffers(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter);
APIRET	dmd_drive_media_attributes(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter);
APIRET	dmd_drive_query_device_params(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter);
APIRET	dmd_drive_query_device_status(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter);
APIRET	dmd_drive_query_device_status_ex(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter);
APIRET	dmd_drive_read_data(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter);
APIRET	dmd_drive_write_data(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter);

/* CDROM Functions (cat 0x80) */
APIRET	dmd_drive_cdrom_reset(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter);
APIRET	dmd_drive_cdrom_eject(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter);
APIRET	dmd_drive_cdrom_close_tray(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter);
APIRET	dmd_drive_cdrom_lock_tray(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter);
APIRET	dmd_drive_cdrom_unlock_tray(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter);
APIRET	dmd_drive_cdrom_seek(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter);
APIRET	dmd_drive_cdrom_query_device_status(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter);
APIRET	dmd_drive_cdrom_query_driver(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter);
APIRET	dmd_drive_cdrom_query_secsize(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter);
APIRET	dmd_drive_cdrom_query_headloc(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter);
APIRET	dmd_drive_cdrom_read_long(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter);
APIRET	dmd_drive_cdrom_query_volsize(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter);
APIRET	dmd_drive_cdrom_query_upc(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter);

/* Test Functions */
APIRET	DmdDoTests(struct OS2CDROMDMD *os2cdromdmd);
void	DumpSRB(SRB* srb);
void	DumpBPB(BIOSPARAMETERBLOCK* bpb);
void	DumpPara(PCHAR para);
void	DumpMem(PCHAR mem, int c);


LOCAL void exit_func_aspi() {
	if (!close_driver())
		js_fprintf(stderr, "Cannot close OS/2-ASPI-Router!\n");
}

LOCAL void exit_func_dmd() {
	if (!close_driver())
		js_fprintf(stderr, "Cannot close OS/2-DMD-Router!\n");
}

LOCAL void
exit_func()
{
	bUseAspi ? exit_func_aspi() : exit_func_dmd();
}

/*
 * Return version information for the low level SCSI transport code.
 * This has been introduced to make it easier to trace down problems
 * in applications.
 */
LOCAL char *
scgo_version(scgp, what)
	SCSI	*scgp;
	int	what;
{
if (bShowFunc) printf("***** %s::%s\n", __FILE__, __FUNCTION__);	// RDPe
	if (scgp != (SCSI *)0) {
		switch (what) {

		case SCG_VERSION:
			return (_scg_trans_version);
		/*
		 * If you changed this source, you are not allowed to
		 * return "schily" for the SCG_AUTHOR request.
		 */
		case SCG_AUTHOR:
			//~ return (_scg_auth_schily);
			return (_scg_auth_rdpe);
		case SCG_SCCS_ID:
			return (__sccsid);
		}
	}
	return ((char *)0);
}

LOCAL int scgo_help_aspi(SCSI* scgp, FILE* f) {
if (bShowFunc) printf("***** %s::%s\n", __FILE__, __FUNCTION__);	// RDPe
	__scg_help(f, "ASPI", "Generic transport independent SCSI",
		"", "bus,target,lun", "1,2,0", TRUE, FALSE);
	return (0);
}

LOCAL int scgo_help_dmd(SCSI* scgp, FILE* f) {
if (bShowFunc) printf("***** %s::%s\n", __FILE__, __FUNCTION__);	// RDPe
	__scg_help(f, "DMD", "Generic transport independent SCSI",
		"", "bus,target,lun", "1,2,0", TRUE, FALSE);
	return (0);
}

LOCAL int
scgo_help(scgp, f)
	SCSI	*scgp;
	FILE	*f;
{
	return bUseAspi ? scgo_help_aspi(scgp, f) : scgo_help_dmd(scgp, f);
}

LOCAL int
scgo_open(scgp, device)
	SCSI	*scgp;
	char	*device;
{
	int	busno	= scg_scsibus(scgp);
	int	tgt	= scg_target(scgp);
	int	tlun	= scg_lun(scgp);

	char *varval = NULL;

	/* See if we want detailed debug-info */
	varval = getenv("LIBSCG_DEBUG");
	bLibscgDebug = varval && varval[0] == '1' ? TRUE : FALSE;

	/* See if the ASPI back-end is desired */
	varval = getenv("LIBSCG_USE_ASPI");
	//~ bUseAspi = varval && varval[0] == '1' ? TRUE : FALSE;

	/* Force using the ASPI backend */
	bUseAspi = TRUE;
	bUseAspi &= varval && varval[0] == '0' ? FALSE : TRUE;

#ifdef VENDOR_BUILD

	/* Force debug-flags off */
	bLibscgDebug = FALSE;
	bShowFunc = FALSE;

	/*
	// We don't want very limited test-builds to function after a short period
	// of time. So, here we check the date and exit if this test-build has
	// expired.
	*/
	do {
		break;
		DATETIME dt;				// structure to hold date and time
		CHAR	bdate_buf[9];		// buffer for ascii bldlevel date
		CHAR	cdate_buf[9];		// buffer for ascii current date
		unsigned long bdate = 0;	// build date
		unsigned long cdate = 0;	// current date
		unsigned long xdate = 0;	// expiry date

		/* Get the current date and time */
		DosGetDateTime(&dt);

		/* Put Build Date into variable -- not actually used */
		sprintf(bdate_buf, "%04d%02d%02d", atoi(BLDLVL_YEAR), atoi(BLDLVL_MONTH), atoi(BLDLVL_DAY));
		bdate = strtoul(bdate_buf, NULL, 16);

		/* Put Current Date into variable */
		sprintf(cdate_buf, "%04d%02d%02d", dt.year, dt.month, dt.day);
		cdate = strtoul(cdate_buf, NULL, 16);

		/* Put Expiry Date into variable */
		xdate = 0x20170401;

		/* Exit if current date is equal or above expiry date */
		if (cdate >= xdate) {
			printf("\n\n");
			printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
			printf("!!! WARNING, THIS IS A VERY OLD TEST-BUILD IN *ALPHA* STATE !!!\n");
			printf("!!! A RELEASE VERSION SHOULD BE AVAILABLE BY NOW            !!!\n");
			printf("!!! CONTINUING TO USE THIS BUILD IS STRONGLY DISCOURAGED    !!!\n");
			printf("!!!                                                         !!!\n");
			printf("!!!                 PAUSING FOR 10 SECONDS                  !!!\n");
			printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
			//~ printf("bdate_buf:%s\n", bdate_buf);
			//~ printf("cdate_buf:%s\n", cdate_buf);
			//~ printf("bdate:%lx\n", (unsigned long) bdate);
			//~ printf("cdate:%lx\n", (unsigned long) cdate);
			//~ printf("xdate:%lx\n", (unsigned long) xdate);
			printf("\n\n");
			DosSleep(10000);
			//~ exit(1);
		}
	} while (0);

#else
	//~ if (bShowFunc) printf("<> %s::%s scgp:0x%08x, f:0x%08x\n", __FILE__, __FUNCTION__, scgp, f);
	printf("############ bLibscgDebug : %d, varval:%08x ############\n", bLibscgDebug, varval);
	printf("############ bUseAspi     : %d, varval:%08x ############\n", bUseAspi, varval);
#endif

	if (busno >= MAX_SCG || tgt >= MAX_TGT || tlun >= MAX_LUN) {
		errno = EINVAL;
		if (scgp->errstr)
			js_snprintf(scgp->errstr, SCSI_ERRSTR_SIZE,
				"Illegal value for busno, target or lun '%d,%d,%d'",
				busno, tgt, tlun);
		return (-1);
	}

	if ((device != NULL && *device != '\0') || (busno == -2 && tgt == -2)) {
		errno = EINVAL;
		if (scgp->errstr)
			js_snprintf(scgp->errstr, SCSI_ERRSTR_SIZE,
				"Open by 'devname' not supported on this OS");
		return (-1);
	}

	if (scgp->local == NULL) {
		scgp->local = malloc(sizeof (struct scg_local));
		if (scgp->local == NULL)
			return (0);
	}

	if (!open_driver(scgp))	/* Try to open ASPI-Router */
		return (-1);
	atexit(exit_func);	/* Install Exit Function which closes the ASPI-Router */

	/*
	 * Success after all
	 */
	return (1);
}

LOCAL int
scgo_close(scgp)
	SCSI	*scgp;
{
if (bShowFunc) printf("***** %s::%s\n", __FILE__, __FUNCTION__);	// RDPe
	exit_func();
	return (0);
}

LOCAL long
scgo_maxdma(scgp, amt)
	SCSI	*scgp;
	long	amt;
{
if (bShowFunc) printf("***** %s::%s\n", __FILE__, __FUNCTION__);	// RDPe
	long maxdma = MAX_DMA_OS2;
	return (maxdma);
}

//! rousseau.comment.201701071509 :: Allocate Buffer

LOCAL void *
scgo_getbuf(scgp, amt)
	SCSI	*scgp;
	long	amt;
{
	ULONG rc;

if (bShowFunc) printf("***** %s::%s amt:%d\n", __FILE__, __FUNCTION__, amt);	// RDPe

//~ #ifdef DEBUG
	if (bLibscgDebug) js_fprintf((FILE *)scgp->errfile, "scgo_getbuf: %ld bytes\n", amt);
//~ #endif
	rc = DosAllocMem(&buffer, amt, OBJ_TILE | PAG_READ | PAG_WRITE | PAG_COMMIT);

	if (rc) {
		js_fprintf((FILE *)scgp->errfile, "Cannot allocate buffer.\n");
		return ((void *)0);
	}
	scgp->bufbase = buffer;

	//! Dirty hack to set buffer size -- should split-up this function
	if (!bUseAspi) os2cdromdmd.bufsize = amt;

//~ #ifdef DEBUG
	if (bLibscgDebug) js_fprintf((FILE *)scgp->errfile, "Buffer allocated at: 0x%x\n", scgp->bufbase);
//~ #endif

	/* Lock memory */
	if (init_buffer(scgp->bufbase))
		return (scgp->bufbase);

	if (bLibscgDebug) js_fprintf((FILE *)scgp->errfile, "Cannot lock memory buffer.\n");
	return ((void *)0); /* Error */
}

LOCAL void scgo_freebuf_aspi(SCSI* scgp) {
if (bShowFunc) printf("***** %s::%s\n", __FILE__, __FUNCTION__);	// RDPe
printf("<> %s::%s\n", __FILE__, __FUNCTION__);

	if (scgp->bufbase && DosFreeMem(scgp->bufbase)) {
		js_fprintf((FILE *)scgp->errfile,
		"Cannot free buffer memory for ASPI-Router!\n"); /* Free our memory buffer if not already done */
	}
	if (buffer == scgp->bufbase)
		buffer = NULL;
	scgp->bufbase = NULL;
}

LOCAL void scgo_freebuf_dmd(SCSI* scgp) {
if (bShowFunc) printf("***** %s::%s\n", __FILE__, __FUNCTION__);	// RDPe
printf("<> %s::%s\n", __FILE__, __FUNCTION__);

	if (scgp->bufbase && DosFreeMem(scgp->bufbase)) {
		js_fprintf((FILE *)scgp->errfile,
		"Cannot free buffer memory for DMD-Router!\n"); /* Free our memory buffer if not already done */
	}
	if (buffer == scgp->bufbase)
		buffer = NULL;
	scgp->bufbase = NULL;
}

LOCAL void
scgo_freebuf(scgp)
	SCSI	*scgp;
{
	bUseAspi ? scgo_freebuf_aspi : scgo_freebuf_dmd;
}

LOCAL int
scgo_numbus(scgp)
	SCSI	*scgp;
{
if (bShowFunc) printf("***** %s::%s\n", __FILE__, __FUNCTION__);	// RDPe
	return (MAX_SCG);
}

LOCAL BOOL
scgo_havebus(scgp, busno)
	SCSI	*scgp;
	int	busno;
{
	register int	t;
	register int	l;
if (bShowFunc) printf("***** %s::%s, busno:%d\n", __FILE__, __FUNCTION__, busno);	// RDPe
	if (busno < 0 || busno >= MAX_SCG)
		return (FALSE);

	return (TRUE);
}

LOCAL int
scgo_fileno(scgp, busno, tgt, tlun)
	SCSI	*scgp;
	int	busno;
	int	tgt;
	int	tlun;
{
if (bShowFunc) printf("***** %s::%s busno:%d, tgt:%d, tlun:%d\n", __FILE__, __FUNCTION__, busno, tgt, tlun);	// RDPe
	if (busno < 0 || busno >= MAX_SCG ||
	    tgt < 0 || tgt >= MAX_TGT ||
	    tlun < 0 || tlun >= MAX_LUN)
		return (-1);

	/*
	 * Return fake
	 */
	return (1);
}


LOCAL int
scgo_initiator_id(scgp)
	SCSI	*scgp;
{
if (bShowFunc) printf("***** %s::%s\n", __FILE__, __FUNCTION__);	// RDPe
	return (-1);
}

LOCAL int
scgo_isatapi(scgp)
	SCSI	*scgp;
{
if (bShowFunc) printf("***** %s::%s\n", __FILE__, __FUNCTION__);	// RDPe
	return (FALSE);
}

//! rousseau.comment.201701071457 :: DosDevIOCtl - reset

LOCAL int scgo_reset_aspi(SCSI* scgp, int what) {
	ULONG	rc;				/* return value */
	ULONG	cbreturn;
	ULONG	cbParam;
	BOOL	success;
static	SRB	SRBlock;			/* XXX makes it non reentrant */
if (bShowFunc) printf("***** %s::%s\n", __FILE__, __FUNCTION__);	// RDPe

	if (what == SCG_RESET_NOP)
		return (0);
	if (what != SCG_RESET_BUS) {
		errno = EINVAL;
		return (-1);
	}
	/*
	 * XXX Does this reset TGT or BUS ???
	 */
	SRBlock.cmd		= SRB_Reset;		/* reset device		*/
	SRBlock.ha_num		= scg_scsibus(scgp);	/* host adapter number	*/
	SRBlock.flags		= SRB_Post;		/* posting enabled	*/
	SRBlock.u.res.target	= scg_target(scgp);	/* target id		*/
	SRBlock.u.res.lun	= scg_lun(scgp);	/* target LUN		*/

	rc = DosDevIOCtl(driver_handle, 0x92, 0x02, (void*) &SRBlock, sizeof (SRB), &cbParam,
			(void*) &SRBlock, sizeof (SRB), &cbreturn);
	if (rc) {
		js_fprintf((FILE *)scgp->errfile,
				"DosDevIOCtl() failed in resetDevice.\n");
		return (1);			/* DosDevIOCtl failed */
	} else {
		success = wait_post(40000);	/** wait for SRB being processed */
		if (success)
			return (2);
	}
	if (SRBlock.status != SRB_Done)
		return (3);
#ifdef DEBUG
	js_fprintf((FILE *)scgp->errfile,
		"resetDevice of host: %d target: %d lun: %d successful.\n", scg_scsibus(scgp), scg_target(scgp), scg_lun(scgp));
	js_fprintf((FILE *)scgp->errfile,
		"SRBlock.ha_status: 0x%x, SRBlock.target_status: 0x%x, SRBlock.satus: 0x%x\n",
				SRBlock.u.cmd.ha_status, SRBlock.u.cmd.target_status, SRBlock.status);
#endif

printf("<< %s::%s\n", __FILE__, __FUNCTION__);

	return (0);
}

LOCAL int scgo_reset_dmd(SCSI* scgp, int what) {
	ULONG	rc;				/* return value */
	ULONG	cbreturn;
	ULONG	cbParam;
	BOOL	success;
static	SRB	SRBlock;			/* XXX makes it non reentrant */
if (bShowFunc) printf("***** %s::%s\n", __FILE__, __FUNCTION__);	// RDPe

	if (what == SCG_RESET_NOP)
		return (0);
	if (what != SCG_RESET_BUS) {
		errno = EINVAL;
		return (-1);
	}
	/*
	 * XXX Does this reset TGT or BUS ???
	 */
	SRBlock.cmd		= SRB_Reset;		/* reset device		*/
	SRBlock.ha_num		= scg_scsibus(scgp);	/* host adapter number	*/
	SRBlock.flags		= SRB_Post;		/* posting enabled	*/
	SRBlock.u.res.target	= scg_target(scgp);	/* target id		*/
	SRBlock.u.res.lun	= scg_lun(scgp);	/* target LUN		*/

	rc = DosDevIOCtl(driver_handle, 0x92, 0x02, (void*) &SRBlock, sizeof (SRB), &cbParam,
			(void*) &SRBlock, sizeof (SRB), &cbreturn);
	if (rc) {
		js_fprintf((FILE *)scgp->errfile,
				"DosDevIOCtl() failed in resetDevice.\n");
		return (1);			/* DosDevIOCtl failed */
	} else {
		success = wait_post(40000);	/** wait for SRB being processed */
		if (success)
			return (2);
	}
	if (SRBlock.status != SRB_Done)
		return (3);
#ifdef DEBUG
	js_fprintf((FILE *)scgp->errfile,
		"resetDevice of host: %d target: %d lun: %d successful.\n", scg_scsibus(scgp), scg_target(scgp), scg_lun(scgp));
	js_fprintf((FILE *)scgp->errfile,
		"SRBlock.ha_status: 0x%x, SRBlock.target_status: 0x%x, SRBlock.satus: 0x%x\n",
				SRBlock.u.cmd.ha_status, SRBlock.u.cmd.target_status, SRBlock.status);
#endif

printf("<< %s::%s\n", __FILE__, __FUNCTION__);

	return (0);
}

//! We never see this one, why not ?
LOCAL int
scgo_reset(scgp, what)
	SCSI	*scgp;
	int	what;
{
	ULONG	rc;				/* return value */
	printf(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> %s::%s\n", __FILE__, __FUNCTION__);
	rc = bUseAspi ? scgo_reset_aspi(scgp, what) : scgo_reset_dmd(scgp, what);
	printf("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< %s::%s\n", __FILE__, __FUNCTION__);
	return rc;
}

/*
 * Set error flags
 */
LOCAL void
set_error(srb, sp)
	SRB	*srb;
	struct scg_cmd	*sp;
{
if (bShowFunc) printf("***** %s::%s\n", __FILE__, __FUNCTION__);	// RDPe
	switch (srb->status) {

	case SRB_InvalidCmd:		/* 0x80 Invalid SCSI request	    */
	case SRB_InvalidHA:		/* 0x81 Invalid host adapter number */
	case SRB_BadDevice:		/* 0x82 SCSI device not installed   */
		sp->error = SCG_FATAL;
		sp->ux_errno = EINVAL;	/* Should we ever return != EIO	    */
		sp->ux_errno = EIO;
		break;


	case SRB_Busy:			/* 0x00 SCSI request in progress    */
	case SRB_Aborted:		/* 0x02 SCSI aborted by host	    */
	case SRB_BadAbort:		/* 0x03 Unable to abort SCSI request */
	case SRB_Error:			/* 0x04 SCSI request completed with error */
	default:
		sp->error = SCG_RETRYABLE;
		sp->ux_errno = EIO;
		break;
	}
}

//! rousseau.comment.201701071201 :: Send SCSI Command

LOCAL int scgo_send_aspi(SCSI* scgp) {
	struct scg_cmd	*sp = scgp->scmd;
	ULONG	rc;				/* return value */
static	SRB	SRBlock;			/* XXX makes it non reentrant */
	Ulong	cbreturn;
	Ulong	cbParam;
	UCHAR*	ptr;

	if (bLibscgDebug) {
		printf("\n\n");
		printf("###############################################################################\n");
		if (bShowFunc) printf("***** %s::%s\n", __FILE__, __FUNCTION__);	// RDPe
		printf("<> %s::%s 0x%02x@(%d,%d,%d)\n   dev:%d, addr:0x%08x, size:%d, flags:0x%02x, cdb.cmd:0x%02X, cdb.cmd_len:%d, cmdname:'%s'\n",
			__FILE__,
			__FUNCTION__,
			scgp->scmd->cdb.g1_cdb.cmd,
			scgp->addr.scsibus,
			scgp->addr.target,
			scgp->addr.lun,
			scgp->dev,
			//~ scgp->fd,
			//~ scgp->scmd->cdb.g1_cdb.lun,
			scgp->scmd->addr,
			scgp->scmd->size,
			scgp->scmd->flags,
			scgp->scmd->cdb.g1_cdb.cmd,
			scgp->scmd->cdb_len,
			scgp->cmdname
		);

		//~ printf("::::::::::::::::::::::::::::::: BEGIN SCSI DUMP :::::::::::::::::::::::::::::::\n");
		//~ DumpMem((PCHAR) scgp, sizeof(SCSI)/16 + 1);
		//~ printf(":::::::::::::::::::::::::::::::: END SCSI DUMP ::::::::::::::::::::::::::::::::\n");
	}

	if (scgp->fd < 0) {			/* Set in scgo_open() */
		sp->error = SCG_FATAL;
		return (0);
	}

	if (sp->cdb_len > sizeof (SRBlock.u.cmd.cdb_st)) { /* commandsize too big */
		sp->error = SCG_FATAL;
		sp->ux_errno = EINVAL;
		js_fprintf((FILE *)scgp->errfile,
			"sp->cdb_len > SRBlock.u.cmd.cdb_st. Fatal error in scgo_send, exiting...\n");
		return (-1);
	}

	/* clear command block */
	fillbytes((caddr_t)&SRBlock.u.cmd.cdb_st, sizeof (SRBlock.u.cmd.cdb_st), '\0');
	/* copy cdrecord command into SRB */
	movebytes(&sp->cdb, &SRBlock.u.cmd.cdb_st, sp->cdb_len);

	/* Build SRB command block */
	SRBlock.cmd = SRB_Command;
	SRBlock.ha_num = scg_scsibus(scgp);	/* host adapter number */

	SRBlock.flags = SRB_Post;		/* flags */

	SRBlock.u.cmd.target	= scg_target(scgp); /* Target SCSI ID */
	SRBlock.u.cmd.lun	= scg_lun(scgp); /* Target SCSI LUN */
	SRBlock.u.cmd.data_len	= sp->size;	/* # of bytes transferred */
	SRBlock.u.cmd.data_ptr	= 0;		/* pointer to data buffer */
	SRBlock.u.cmd.sense_len	= sp->sense_len; /* length of sense buffer */

	SRBlock.u.cmd.link_ptr	= 0;		/* pointer to next SRB */
	SRBlock.u.cmd.cdb_len	= sp->cdb_len;	/* SCSI command length */

	/* Specify direction */
	if (sp->flags & SCG_RECV_DATA) {
		SRBlock.flags |= SRB_Read;
	} else {
		if (sp->size > 0) {
			SRBlock.flags |= SRB_Write;
			if (scgp->bufbase != sp->addr) { /* Copy only if data not in ASPI-Mem */
				movebytes(sp->addr, scgp->bufbase, sp->size);
			}
		} else {
			SRBlock.flags |= SRB_NoTransfer;
		}
	}
	sp->error	= SCG_NO_ERROR;
	sp->sense_count	= 0;
	sp->u_scb.cmd_scb[0] = 0;
	sp->resid	= 0;

//! rousseau.comment.201612301821 :: DosDevIOCtl - execute scsi-ommand against 'aspirou$'

	if (bLibscgDebug) {
	//~ if (scgp->scmd->cdb.g1_cdb.cmd == 0x00) {
		printf("\n");
		printf("------------- BEFORE IOCTL -------------\n");
		DumpSRB(&SRBlock);
		printf("----------------------------------------\n");
	}



//! ============================================================= [PROCESS SRB]
	/* Process SRB -- aspirou$ driver */
	rc = DosDevIOCtl(driver_handle, 0x92, 0x02,
			(void*) &SRBlock, sizeof (SRB), &cbParam,
			(void*) &SRBlock, sizeof (SRB), &cbreturn);
//! ===========================================================================



#ifndef VENDOR_BUILD
	printf("ASPI-PROCESS-SRB:  rc:%d\n", rc);
#endif
	if (bLibscgDebug) {
	//~ if (scgp->scmd->cdb.g1_cdb.cmd == 0x00) {
		printf("\n");
		printf("--------- AFTER  IOCTL (rc:%d) ---------\n", rc);
		DumpSRB(&SRBlock);
		printf("----------------------------------------\n");
		printf("\n");
	}

	if (rc) {		/* An error occured */
		js_fprintf((FILE *)scgp->errfile,
				"DosDevIOCtl() in sendCommand failed, rc=%d\n", rc);	// returns 6, ERROR_INVALID_HANDLE (os2cdrom.dmd)
		sp->error = SCG_FATAL;
		sp->ux_errno = EIO;	/* Sp�ter vielleicht errno einsetzen */
		return (rc);
	} else {
		/* Wait until the command is processed */
		rc = wait_post(sp->timeout*1000);
		if (bLibscgDebug) printf("!! wait_post rc:%d\n", rc);		// RDPe
		if (rc) {	/* An error occured */
			if (rc == 640) {
				/* Timeout */
				sp->error = SCG_TIMEOUT;
				sp->ux_errno = EIO;
				js_fprintf((FILE *)scgp->errfile,
						"Timeout during SCSI-Command.\n");
				return (1);
			}
			sp->error = SCG_FATAL;
			sp->ux_errno = EIO;
			js_fprintf((FILE *)scgp->errfile,
					"Fatal Error during DosWaitEventSem().\n");
			return (1);
		}

		/* The command is processed */
#ifndef VENDOR_BUILD
		if (bLibscgDebug)
			printf("=====> SRBlock.status:%d\n", SRBlock.status);	// RDPe
#endif
		if (SRBlock.status == SRB_Done) {	/* succesful completion */
#ifdef DEBUG
			js_fprintf((FILE *)scgp->errfile,
				"Command successful finished. SRBlock.status=0x%x\n\n", SRBlock.status);
#endif
			sp->sense_count = 0;
			sp->resid = 0;
			if (sp->flags & SCG_RECV_DATA) {	/* We read data */
				if (sp->addr && sp->size) {

					if (bLibscgDebug) {
						printf("+++++++++++++\n");
						DumpMem(sp->addr, sp->size/16+1);
						printf("+++++++++++++\n");
					}

					if (scgp->bufbase != sp->addr)	/* Copy only if data not in ASPI-Mem */
						movebytes(scgp->bufbase, sp->addr, SRBlock.u.cmd.data_len);
					ptr = (UCHAR*)sp->addr;
					sp->resid = sp->size - SRBlock.u.cmd.data_len; /*nicht �bertragene bytes. Korrekt berechnet???*/
				}
			}	/* end of if (sp->flags & SCG_RECV_DATA) */
			if (SRBlock.u.cmd.target_status == SRB_CheckStatus) { /* Sense data valid */
				sp->sense_count	= (int)SRBlock.u.cmd.sense_len;
				if (sp->sense_count > sp->sense_len)
					sp->sense_count = sp->sense_len;

				ptr = (UCHAR*)&SRBlock.u.cmd.cdb_st;
				ptr += SRBlock.u.cmd.cdb_len;

				fillbytes(&sp->u_sense.Sense, sizeof (sp->u_sense.Sense), '\0');
				movebytes(ptr, &sp->u_sense.Sense, sp->sense_len);

				sp->u_scb.cmd_scb[0] = SRBlock.u.cmd.target_status;
				sp->ux_errno = EIO;	/* Sp�ter differenzieren? */
			}

			/* Dump Return Data */
			if (bLibscgDebug) {
				printf("\n");
				printf("===============================================================================\n");
				if (scgp->bufbase && sp->addr) {
					printf("!! BEGIN RETURN DATA !!\n");
					printf("scgp->bufbase (0x%08x):\n", scgp->bufbase);
					DumpMem(scgp->bufbase, 1);
					printf("sp->addr      (0x%08x):\n", sp->addr);
					DumpMem(sp->addr, SRBlock.u.cmd.data_len/16+1);
					printf("!! END RETURN DATA !!\n");
				}
				else {
					printf("!! NO RETURN DATA !!\n");
				}
				printf("===============================================================================\n");
				printf("\n");
				//~ printf("::::::::::::::::::::::::::::::: BEGIN SCSI DUMP :::::::::::::::::::::::::::::::\n");
				//~ DumpMem((PCHAR) scgp, sizeof(SCSI)/16 + 1);
				//~ printf(":::::::::::::::::::::::::::::::: END SCSI DUMP ::::::::::::::::::::::::::::::::\n");
			}

			return (0);
		}
		/* SCSI-Error occured */
		set_error(&SRBlock, sp);

		if (SRBlock.u.cmd.target_status == SRB_CheckStatus) {	/* Sense data valid */
			sp->sense_count	= (int)SRBlock.u.cmd.sense_len;
			if (sp->sense_count > sp->sense_len)
				sp->sense_count = sp->sense_len;

			ptr = (UCHAR*)&SRBlock.u.cmd.cdb_st;
			ptr += SRBlock.u.cmd.cdb_len;

			fillbytes(&sp->u_sense.Sense, sizeof (sp->u_sense.Sense), '\0');
			movebytes(ptr, &sp->u_sense.Sense, sp->sense_len);

			sp->u_scb.cmd_scb[0] = SRBlock.u.cmd.target_status;
		}
		if (sp->flags & SCG_RECV_DATA) {
			if (sp->addr && sp->size) {
				if (scgp->bufbase != sp->addr)	/* Copy only if data not in ASPI-Mem */
					movebytes(scgp->bufbase, sp->addr, SRBlock.u.cmd.data_len);
			}
		}
#ifdef	really
		sp->resid	= SRBlock.u.cmd.data_len; /* XXXXX Got no Data ????? */
#else
		sp->resid	= sp->size - SRBlock.u.cmd.data_len;
#endif

#ifndef VENDOR_BUILD
printf("<< %s::%s\n", __FILE__, __FUNCTION__);
#endif
		return (1);
	}
}

LOCAL int scgo_send_dmd(SCSI* scgp) {
	struct scg_cmd	*sp = scgp->scmd;
	//~ struct ExecCMD2 ecmd2;
	//~ CHAR	pbuf[512];
	//~ CHAR	dbuf[512];
	ULONG	rc;				/* return value */
static	SRB	SRBlock;			/* XXX makes it non reentrant */
	Ulong	cbreturn;
	Ulong	cbParam;
	UCHAR*	ptr;

	if (bLibscgDebug) {
		printf("\n\n");
		if (bShowFunc) printf("***** %s::%s\n", __FILE__, __FUNCTION__);	// RDPe
		printf("###############################################################################\n");
		printf("<> %s::%s 0x%02x@(%d,%d,%d)\n   dev:%d, addr:0x%08x, size:%d, flags:0x%02x, cdb.cmd:0x%02X, cdb.cmd_len:%d, cmdname:'%s'\n",
			__FILE__,
			__FUNCTION__,
			scgp->scmd->cdb.g1_cdb.cmd,
			scgp->addr.scsibus,
			scgp->addr.target,
			scgp->addr.lun,
			scgp->dev,
			//~ scgp->fd,
			//~ scgp->scmd->cdb.g1_cdb.lun,
			scgp->scmd->addr,
			scgp->scmd->size,
			scgp->scmd->flags,
			scgp->scmd->cdb.g1_cdb.cmd,
			scgp->scmd->cdb_len,
			scgp->cmdname
		);

		//~ printf("::::::::::::::::::::::::::::::: BEGIN SCSI DUMP :::::::::::::::::::::::::::::::\n");
		//~ DumpMem((PCHAR) scgp, sizeof(SCSI)/16 + 1);
		//~ printf(":::::::::::::::::::::::::::::::: END SCSI DUMP ::::::::::::::::::::::::::::::::\n");
	}

	/* zero command structure */
	//~ memset(&ecmd2, 0, sizeof(struct ExecCMD2));

	/* zero the ioctl buffers */
	//~ memset(pbuf, 0, sizeof(pbuf));
	//~ memset(dbuf, 0, sizeof(dbuf));

	if (scgp->fd < 0) {			/* Set in scgo_open() */
		sp->error = SCG_FATAL;
		return (0);
	}

	if (sp->cdb_len > sizeof (SRBlock.u.cmd.cdb_st)) { /* commandsize too big */
		sp->error = SCG_FATAL;
		sp->ux_errno = EINVAL;
		js_fprintf((FILE *)scgp->errfile,
			"sp->cdb_len > SRBlock.u.cmd.cdb_st. Fatal error in scgo_send, exiting...\n");
		return (-1);
	}

	/* clear command block */
	fillbytes((caddr_t)&SRBlock.u.cmd.cdb_st, sizeof (SRBlock.u.cmd.cdb_st), '\0');
	/* copy cdrecord command into SRB */
	movebytes(&sp->cdb, &SRBlock.u.cmd.cdb_st, sp->cdb_len);

	/* Build SRB command block */
	SRBlock.cmd = SRB_Command;
	SRBlock.ha_num = scg_scsibus(scgp);	/* host adapter number */

	SRBlock.flags = SRB_Post;		/* flags */

	SRBlock.u.cmd.target	= scg_target(scgp); /* Target SCSI ID */
	SRBlock.u.cmd.lun	= scg_lun(scgp); /* Target SCSI LUN */
	SRBlock.u.cmd.data_len	= sp->size;	/* # of bytes transferred */
	SRBlock.u.cmd.data_ptr	= 0;		/* pointer to data buffer */
	SRBlock.u.cmd.sense_len	= sp->sense_len; /* length of sense buffer */

	SRBlock.u.cmd.link_ptr	= 0;		/* pointer to next SRB */
	SRBlock.u.cmd.cdb_len	= sp->cdb_len;	/* SCSI command length */

	/* Specify direction */
	if (sp->flags & SCG_RECV_DATA) {
		SRBlock.flags |= SRB_Read;
	} else {
		if (sp->size > 0) {
			SRBlock.flags |= SRB_Write;
			if (scgp->bufbase != sp->addr) { /* Copy only if data not in ASPI-Mem */
				movebytes(sp->addr, scgp->bufbase, sp->size);
			}
		} else {
			SRBlock.flags |= SRB_NoTransfer;
		}
	}
	sp->error	= SCG_NO_ERROR;
	sp->sense_count	= 0;
	sp->u_scb.cmd_scb[0] = 0;
	sp->resid	= 0;

//! rousseau.comment.201702101104 :: DosDevIOCtl - execute scsi-ommand against 'cd-rom2$'

	/* execute SCSI	command */
	//~ rc = DosDevIOCtl(driver_handle, 0x92, 0x02,
			//~ (void*) &SRBlock, sizeof (SRB), &cbParam,
			//~ (void*) &SRBlock, sizeof (SRB), &cbreturn);

	//~ ecmd2.unit = 'S' - 'A';									// drive index (0=A)
	//~ ecmd2.data_length = 256;								// clipses response length
	//~ ecmd2.cmd_length = 16;									// cannot be >16 for os2cdrom.dmd
	//~ ecmd2.flags = 0x00;										// 0x04 includes retstat _after_ ecmd.data_length
	//~ memset(ecmd2.cmd_buffer, 0, 16);						// clear command buffer
//! rousseau.comment.201702101729 :: Copy SCSI-command to DosDevIOCtl param buffer
	//~ memcpy(ecmd2.cmd_buffer, &SRBlock.u.cmd.cdb_st, 16);	// copy CDB to command buffer
	//~ ecmd2.cmd_timeout = 0;

	//~ memcpy(pbuf, &ecmd2, sizeof(struct ExecCMD2));

	if (bLibscgDebug) {
	//~ if (scgp->scmd->cdb.g1_cdb.cmd == 0x00) {
		printf("\n");
		printf("------------- BEFORE IOCTL -------------\n");
		DumpSRB(&SRBlock);
		printf("----------------------------------------\n");
	}



//! ============================================================= [PROCESS SRB]
	/* Process SRB -- cd-rom2$ driver */
	rc = dmd_drive_scsi_process_srb(&os2cdromdmd, &SRBlock, sizeof(SRB));
//! ===========================================================================



#ifndef VENDOR_BUILD
	printf("DMD-PROCESS-SRB:   rc:%d\n", rc);
#endif
	/* execute scsi-command-2 */
	//~ rc =	DosDevIOCtl(
				//~ driver_handle,				// hDevice
				//~ 0x82,						// category
				//~ 0x7a,						// function
				//~ (void*) pbuf,				// pParams
				//~ sizeof(pbuf),				// cbParmLenMax
				//~ &cbParam,					// pcbParmLen
				//~ (void*) dbuf,				// pData
				//~ sizeof(dbuf),				// cbDataLenMax
				//~ &cbreturn					// pcbDataLen
			//~ );

	if (bLibscgDebug) {
	//~ if (scgp->scmd->cdb.g1_cdb.cmd == 0x00) {
		printf("\n");
		printf("--------- AFTER  IOCTL (rc:%d) ---------\n", rc);
		DumpSRB(&SRBlock);
		printf("----------------------------------------\n");
		printf("\n");
		//~ printf("!! DMD RETURN DATA !!\n");
		//~ DumpPara(dbuf);
		//~ printf("\n");
		//~ printf("!! DMD RETURN STATUS !!\n");
		//~ DumpPara(dbuf+256);
		//~ printf("\n");
	}

	/* force posting of semaphore */
	DosPostEventSem(postSema);

	if (rc) {		/* An error occured */
		js_fprintf((FILE *)scgp->errfile,
				"dmd_drive_scsi_process_srb() in sendCommand failed, rc=%d, cmd:%02x\n", rc, SRBlock.u.cmd.cdb_st[0]);	// returns 6, ERROR_INVALID_HANDLE (os2cdrom.dmd)
		sp->error = SCG_FATAL;
		sp->ux_errno = EIO;	/* Sp�ter vielleicht errno einsetzen */
		return (rc);
	} else {
		/* Wait until the command is processed */
		rc = wait_post(sp->timeout*1000);
		if (bLibscgDebug) printf("!! wait_post rc:%d\n", rc);		// RDPe
		if (rc) {	/* An error occured */
			if (rc == 640) {
				/* Timeout */
				sp->error = SCG_TIMEOUT;
				sp->ux_errno = EIO;
				js_fprintf((FILE *)scgp->errfile,
						"Timeout during SCSI-Command.\n");
				return (1);
			}
			sp->error = SCG_FATAL;
			sp->ux_errno = EIO;
			js_fprintf((FILE *)scgp->errfile,
					"Fatal Error during DosWaitEventSem().\n");
			return (1);
		}

		/* The command is processed */
#ifndef VENDOR_BUILD
		if (bLibscgDebug)
			printf("=====> SRBlock.status:%d\n", SRBlock.status);	// RDPe
#endif
		if (SRBlock.status == SRB_Done) {	/* succesful completion */
#ifdef DEBUG
			js_fprintf((FILE *)scgp->errfile,
				"Command successful finished. SRBlock.status=0x%x\n\n", SRBlock.status);
#endif
			sp->sense_count = 0;
			sp->resid = 0;
			if (sp->flags & SCG_RECV_DATA) {	/* We read data */
				if (sp->addr && sp->size) {

					if (bLibscgDebug) {
						printf("+++++++++++++\n");
						DumpMem(os2cdromdmd.buffer, sp->size/16+1);
						printf("+++++++++++++\n");
					}

					/* Copy data to buffer */
					memcpy(sp->addr, os2cdromdmd.buffer, sp->size);

					if (bLibscgDebug) printf("###### scgp->bufbase:0x%08x, sp:0x%08x, sp->addr:0x%08x, sp->size:%d, cmd.data_len:%d\n", scgp->bufbase, sp, sp->addr, sp->size, SRBlock.u.cmd.data_len);

					/*
					// rousseau.comment.201702210954
					// This copies from scgp->bufbase to sp->addr !!
					// Thus overwriting the returned data sp-addr points to. !!
					// The pointers are almost never the same, except when
					// reading sector 0.
					// This seems to be something having to do with caching
					// related to the ASPI-driver, so we disable it here.
					*/
					//~ if (scgp->bufbase != sp->addr)	/* Copy only if data not in ASPI-Mem */
						//~ movebytes(scgp->bufbase, sp->addr, SRBlock.u.cmd.data_len);

					ptr = (UCHAR*)sp->addr;
					sp->resid = sp->size - SRBlock.u.cmd.data_len; /*nicht �bertragene bytes. Korrekt berechnet???*/
				}
			}	/* end of if (sp->flags & SCG_RECV_DATA) */
			if (SRBlock.u.cmd.target_status == SRB_CheckStatus) { /* Sense data valid */
				sp->sense_count	= (int)SRBlock.u.cmd.sense_len;
				if (sp->sense_count > sp->sense_len)
					sp->sense_count = sp->sense_len;

				ptr = (UCHAR*)&SRBlock.u.cmd.cdb_st;
				ptr += SRBlock.u.cmd.cdb_len;

				fillbytes(&sp->u_sense.Sense, sizeof (sp->u_sense.Sense), '\0');
				movebytes(ptr, &sp->u_sense.Sense, sp->sense_len);

				sp->u_scb.cmd_scb[0] = SRBlock.u.cmd.target_status;
				sp->ux_errno = EIO;	/* Sp�ter differenzieren? */
			}

			/* Dump Return Data */
			if (bLibscgDebug) {
				printf("\n");
				printf("===============================================================================\n");
				if (scgp->bufbase && sp->addr) {
					printf("!! BEGIN RETURN DATA !!\n");
					printf("scgp->bufbase (0x%08x):\n", scgp->bufbase);
					DumpMem(scgp->bufbase, 1);
					printf("sp->addr      (0x%08x):\n", sp->addr);
					DumpMem(sp->addr, SRBlock.u.cmd.data_len/16+1);
					printf("!! END RETURN DATA !!\n");
				}
				else {
					printf("!! NO RETURN DATA !!\n");
				}
				printf("===============================================================================\n");
				printf("\n");

				//~ printf("::::::::::::::::::::::::::::::: BEGIN SCSI DUMP :::::::::::::::::::::::::::::::\n");
				//~ DumpMem((PCHAR) scgp, sizeof(SCSI)/16 + 1);
				//~ printf(":::::::::::::::::::::::::::::::: END SCSI DUMP ::::::::::::::::::::::::::::::::\n");
			}

			return (0);
		}
		/* SCSI-Error occured */
		set_error(&SRBlock, sp);

		if (SRBlock.u.cmd.target_status == SRB_CheckStatus) {	/* Sense data valid */
			sp->sense_count	= (int)SRBlock.u.cmd.sense_len;
			if (sp->sense_count > sp->sense_len)
				sp->sense_count = sp->sense_len;

			ptr = (UCHAR*)&SRBlock.u.cmd.cdb_st;
			ptr += SRBlock.u.cmd.cdb_len;

			fillbytes(&sp->u_sense.Sense, sizeof (sp->u_sense.Sense), '\0');
			movebytes(ptr, &sp->u_sense.Sense, sp->sense_len);

			sp->u_scb.cmd_scb[0] = SRBlock.u.cmd.target_status;
		}
		if (sp->flags & SCG_RECV_DATA) {
			if (sp->addr && sp->size) {
				if (scgp->bufbase != sp->addr)	/* Copy only if data not in ASPI-Mem */
					movebytes(scgp->bufbase, sp->addr, SRBlock.u.cmd.data_len);
			}
		}
#ifdef	really
		sp->resid	= SRBlock.u.cmd.data_len; /* XXXXX Got no Data ????? */
#else
		sp->resid	= sp->size - SRBlock.u.cmd.data_len;
#endif

#ifndef VENDOR_BUILD
printf("<< %s::%s\n", __FILE__, __FUNCTION__);
#endif
		return (1);
	}
}

LOCAL int
scgo_send(scgp)
	SCSI	*scgp;
{
	ULONG	rc;				/* return value */

#ifndef	VENDOR_BUILD
	printf("\n");
	printf("###############################################################################\n");
	printf(">> %s::%s 0x%02x@(%d,%d,%d)#0x%08x -- scmd.addr:0x%08x -- '%s'\n", __FILE__, __FUNCTION__, scgp->scmd->cdb.g1_cdb.cmd, scgp->addr.scsibus, scgp->addr.target, scgp->addr.lun, scgp->scmd->size, scgp->scmd->addr, scgp->cmdname);
	printf(":::::::::: sense_len:%d, sense_count:%d, flags:0x%08x\n", scgp->scmd->sense_len, scgp->scmd->sense_count, scgp->scmd->flags);

	/* Don't dump 'TEST UNIT' */
	//~ if (scgp->scmd->cdb.g1_cdb.cmd != 0x00) {

		/* Dump scsi command */
		printf("[scgp->scmd->cdb]  ");
		DumpPara(&scgp->scmd->cdb);
		printf("\n");

		if (scgp->local)   {printf("[local]            "); DumpPara(scgp->local); printf("\n");}
		if (scgp->bufbase) {printf("[bufbase]          "); DumpPara(scgp->bufbase); printf("\n");}
		if (scgp->bufptr)  {printf("[bufptr]           "); DumpPara(scgp->bufptr); printf("\n");}
	//~ }
#endif

	/* Delegate to ASPI or DMD */
	rc = bUseAspi ? scgo_send_aspi(scgp) : scgo_send_dmd(scgp);

#ifndef	VENDOR_BUILD
	/* Don't dump 'TEST UNIT' */
	//~ if (scgp->scmd->cdb.g1_cdb.cmd != 0x00) {

		if (scgp->local)   {printf("[local]            "); DumpPara(scgp->local); printf("\n");}
		if (scgp->bufbase) {printf("[bufbase]          "); DumpPara(scgp->bufbase); printf("\n");}
		if (scgp->bufptr)  {printf("[bufptr]           "); DumpPara(scgp->bufptr); printf("\n");}

		/* Dump 1st paragraph of result, if any */
		if (scgp->scmd->addr) {
			printf("[scgp->scmd->addr] ");
			DumpPara(scgp->scmd->addr);
			printf("\n");
		}
		else {
			printf("*** NO RESULT ***\n");
		}
	//~ }

	printf("<< %s::%s 0x%02x@(%d,%d,%d) -- rc:%d%s\n", __FILE__, __FUNCTION__, scgp->scmd->cdb.g1_cdb.cmd, scgp->addr.scsibus, scgp->addr.target, scgp->addr.lun, rc, rc?" !!!!!!!!!":"");
#endif

	return rc;
}

LOCAL BOOL open_driver_aspi(SCSI* scgp) {
	ULONG	rc;			/* return value */
	ULONG	ActionTaken;		/* return value	*/
	USHORT	openSemaReturn;		/* return value	*/
	ULONG	cbreturn;
	ULONG	cbParam;

if (bShowFunc) printf("***** %s::%s\n", __FILE__, __FUNCTION__);	// RDPe

	if (driver_handle)		/* ASPI-Router already opened	*/
		return (TRUE);

	/* name of the driver to open */
	drivername = "aspirou$";

	if (bLibscgDebug) printf("Opening driver: '%s'\n", drivername);

//! rousseau.comment.201612301127 :: Open Driver (ASPI)

	/* open the driver */
	rc = DosOpen(
			drivername,
			&driver_handle,
			&ActionTaken,
			0,
			0,
			FILE_OPEN,
			OPEN_SHARE_DENYREADWRITE | OPEN_ACCESS_READWRITE,
			NULL
		);

	/* abort if driver could not be opened */
	if (rc) {
		js_fprintf((FILE *)scgp->errfile, "**ERROR: Cannot open ASPI-Router (%s) !!\n", drivername);
		return (FALSE);		/* opening failed -> return false*/
	}

	/* Init semaphore */
	if (DosCreateEventSem(NULL, &postSema,	/* create event semaphore */
				DC_SEM_SHARED, 0)) {
		DosClose(driver_handle);
		js_fprintf((FILE *)scgp->errfile, "Cannot create event semaphore!\n");

		return (FALSE);
	}

//! rousseau.comment.201612301127 :: DosDevIOCtl - pass semaphore to driver

	/* pass semaphore handle to driver */
	rc = DosDevIOCtl(
			driver_handle,				// hDevice
			0x92,						// category
			0x03,						// function
			(void*) &postSema,			// pParams
			sizeof (HEV),				// cbParmLenMax
			&cbParam,					// pcbParmLen
			(void*) &openSemaReturn,	// pData
			sizeof (USHORT),			// cbDataLenMax
			&cbreturn					// pcbDataLen
		);

	/* check for error on passing the semaphore to the driver */
	if (rc||openSemaReturn) {
		DosCloseEventSem(postSema);
		DosClose(driver_handle);
		//! rousseau.comment.201612301238: returns rc=65283 -- (no description found yet)
		js_fprintf((FILE *)scgp->errfile, "Error passing semaphore to driver! -- rc:%d, osr:%d\n", rc, openSemaReturn);
		return (FALSE);
	}
	return (TRUE);
}

LOCAL BOOL open_driver_dmd(SCSI* scgp) {
	ULONG	rc;			/* return value */
	ULONG	rc2;		/* return value 2 */
	ULONG	rc3;		/* return value 3 */
	ULONG	ActionTaken;		/* return value	*/
	USHORT	openSemaReturn;		/* return value	*/
	ULONG	cbreturn;
	ULONG	cbParam;

if (bShowFunc) printf("***** %s::%s\n", __FILE__, __FUNCTION__);	// RDPe
	if (driver_handle)		/* DMD-Router already opened	*/
		return (TRUE);

	/* name of the driver to open */
	drivername = "cd-rom2$";

//! rousseau.comment.201612301127 :: Open Driver (DMD)

	/* Open the driver */
	rc = dmd_open(&os2cdromdmd);

	/* Assign the driver handle on successful open */
	driver_handle = rc ? -1 : os2cdromdmd.handle;

	/* abort if driver could not be opened */
	if (rc) {
		js_fprintf((FILE *)scgp->errfile, "**ERROR: Cannot open OS2CDROM.DMD (%s) !!\n", drivername);
		return (FALSE);		/* opening failed -> return false*/
	}

	/* Init semaphore */
	if (DosCreateEventSem(NULL, &postSema,	/* create event semaphore */
				DC_SEM_SHARED, 0)) {
		dmd_close(&os2cdromdmd);
		driver_handle = NULL;
		js_fprintf((FILE *)scgp->errfile, "Cannot create event semaphore!\n");

		return (FALSE);
	}

//~ //! rousseau.comment.201612301127 :: DosDevIOCtl - pass semaphore to driver

	/* pass semaphore handle to driver */
	//~ rc = DosDevIOCtl(
			//~ driver_handle,				// hDevice
			//~ 0x92,						// category
			//~ 0x03,						// function
			//~ (void*) &postSema,			// pParams
			//~ sizeof (HEV),				// cbParmLenMax
			//~ &cbParam,					// pcbParmLen
			//~ (void*) &openSemaReturn,	// pData
			//~ sizeof (USHORT),			// cbDataLenMax
			//~ &cbreturn					// pcbDataLen
		//~ );

	//~ /* check for error on passing the semaphore to the driver */
	//~ if (rc||openSemaReturn) {
		//~ DosCloseEventSem(postSema);
		//~ DosClose(driver_handle);
		//~ //! rousseau.comment.201612301238: returns rc=65283 -- (no description found yet)
		//~ js_fprintf((FILE *)scgp->errfile, "Error passing semaphore to driver! -- rc:%d, osr:%d\n", rc, openSemaReturn);
		//~ return (FALSE);
	//~ }


	/* Initialize the driver structure */
	rc2 = dmd_init(&os2cdromdmd);

	/* Get drives handled by 'os2cdrom.dmd' */
	rc3 = dmd_query_drives(&os2cdromdmd);

	/* Do some tests to verify functioning of the dmd wrapper functions */
	//~ rc = DmdDoTests(&os2cdromdmd);

	return (TRUE);
}

/***************************************************************************
 *									   *
 *  BOOL open_driver()							   *
 *									   *
 *  Opens the ASPI Router device driver and sets device_handle.		   *
 *  Returns:								   *
 *    TRUE - Success							   *
 *    FALSE - Unsuccessful opening of device driver			   *
 *									   *
 *  Preconditions: ASPI Router driver has be loaded			   *
 *									   *
 ***************************************************************************/
LOCAL BOOL
open_driver(scgp)
	SCSI	*scgp;
{
	ULONG	rc;			/* return value */

	/* Open the driver based on the back-end (ASPI or DMD) used */
	rc = bUseAspi ? open_driver_aspi(scgp) : open_driver_dmd(scgp);

	return (rc);
}

LOCAL BOOL close_driver_aspi() {
	ULONG rc;				/* return value */

	if (driver_handle) {
		rc = DosClose(driver_handle);
		if (rc)
			return (FALSE);		/* closing failed -> return false */
		driver_handle = 0;
		if (DosCloseEventSem(postSema))
			js_fprintf(stderr, "Cannot close event semaphore!\n");
		if (buffer && DosFreeMem(buffer)) {
			js_fprintf(stderr,
			"Cannot free buffer memory for ASPI-Router!\n"); /* Free our memory buffer if not already done */
		}
		buffer = NULL;
	}
	return (TRUE);
}

LOCAL BOOL close_driver_dmd() {
	ULONG rc;				/* return value */

	if (driver_handle) {
		/* Close the driver */
		rc = dmd_close(&os2cdromdmd);
		/* Nullify handle on successful close */
		driver_handle = rc ? driver_handle : NULL;
		if (rc)
			return (FALSE);		/* closing failed -> return false */
		if (DosCloseEventSem(postSema))
			js_fprintf(stderr, "Cannot close event semaphore!\n");
		if (buffer && DosFreeMem(buffer)) {
			js_fprintf(stderr,
			"Cannot free buffer memory for DMD-Router!\n"); /* Free our memory buffer if not already done */
		}
		buffer = NULL;
	}
	return (TRUE);
}

/***************************************************************************
 *									   *
 *  BOOL close_driver()							   *
 *									   *
 *  Closes the device driver						   *
 *  Returns:								   *
 *    TRUE - Success							   *
 *    FALSE - Unsuccessful closing of device driver			   *
 *									   *
 *  Preconditions: ASPI Router driver has be opened with open_driver	   *
 *									   *
 ***************************************************************************/
LOCAL BOOL
close_driver()
{
	ULONG rc;				/* return value */
	rc = bUseAspi ? close_driver_aspi() : close_driver_dmd();
	return rc;
}

LOCAL ULONG
wait_post(ULONG ulTimeOut)
{
	ULONG count = 0;
	ULONG rc;					/* return value */
if (bShowFunc) printf("***** %s::%s, timeout:%d\n", __FILE__, __FUNCTION__, ulTimeOut);	// RDPe
/*	rc = DosWaitEventSem(postSema, -1);*/		/* wait forever*/
	rc = DosWaitEventSem(postSema, ulTimeOut);
	DosResetEventSem(postSema, &count);
	return (rc);
}

//! rousseau.comment.201701071455 :: DosDevIOCtl - pass buffer to driver

LOCAL BOOL init_buffer_aspi(void* mem) {
	ULONG	rc;					/* return value */
	USHORT lockSegmentReturn;			/* return value */
	Ulong	cbreturn;
	Ulong	cbParam;

	if (bShowFunc) printf("<> %s::%s mem:0x%08x\n", __FILE__, __FUNCTION__, mem);

	/* pass pointer to buffer to driver */
	rc = DosDevIOCtl(
			driver_handle,
			0x92,
			0x04,
			(void*) mem,
			sizeof (void*),
			&cbParam,
			(void*) &lockSegmentReturn,
			sizeof (USHORT),
			&cbreturn
		);

	if (rc)
		return (FALSE);				/* DosDevIOCtl failed */
	if (lockSegmentReturn)
		return (FALSE);				/* Driver could not lock segment */

	return (TRUE);
}

LOCAL BOOL init_buffer_dmd(void* mem) {
	ULONG	rc;					/* return value */
	USHORT lockSegmentReturn;			/* return value */
	Ulong	cbreturn;
	Ulong	cbParam;
	if (bShowFunc) printf("<> %s::%s mem:0x%08x\n", __FILE__, __FUNCTION__, mem);

	/* pass pointer to buffer to driver */
	//~ rc = DosDevIOCtl(
			//~ driver_handle,
			//~ 0x92,
			//~ 0x04,
			//~ (void*) mem,
			//~ sizeof (void*),
			//~ &cbParam,
			//~ (void*) &lockSegmentReturn,
			//~ sizeof (USHORT),
			//~ &cbreturn
		//~ );

	/* Provide access to the buffer for the DMD driver */
	os2cdromdmd.buffer = mem;

	//~ if (rc)
		//~ return (FALSE);				/* DosDevIOCtl failed */
	//~ if (lockSegmentReturn)
		//~ return (FALSE);				/* Driver could not lock segment */

	return (TRUE);
}

LOCAL BOOL
init_buffer(mem)
	void	*mem;
{
	ULONG	rc;					/* return value */
	rc = bUseAspi ? init_buffer_aspi(mem) : init_buffer_dmd(mem);
	return (rc);
}
#define	sense	u_sense.Sense



/* ######################################################################### */
/* ############################ IOCTL FUNCTIONS ############################ */
/* ######################################################################### */


/*****************************************************************************\
* Open the driver presented by 'os2cdrom.dmd'                                 *
* --------------------------------------------------------------------------- *
* The 'os2cdrom.dmd' driver handles ATAPI and USB devices.                    *
* At driver initialization, drive letters are connected to the devices found. *
*                                                                             *
* This function opens the driver so it can be accessed by IOCTL functions.    *
\*****************************************************************************/
APIRET	dmd_open(struct OS2CDROMDMD *os2cdromdmd) {
	APIRET	rc = -123;
	HFILE	handle = -1;
	ULONG	ActionTaken = 0;

	if (bLibscgDebug) printf("Opening driver: '%s'\n", "cd-rom2$");

	if (bShowFunc) printf(">> %s::%s os2cdromdmd:0x%08x\n", __FILE__, __FUNCTION__, os2cdromdmd);

	/* A do-block with mutiple exit points */
	do {
		//~ break;

		/* Check for NULL pointer */
		if (os2cdromdmd == NULL) break;

		/* Get the driver handle -- NULL or -1 indicates driver not open */
		handle = os2cdromdmd->handle;

		/* Open the driver */
		if (handle == NULL || handle == -1) {
			rc =	DosOpen(
						(PCSZ) "cd-rom2$",			// driver to open
						&handle,					// handle to receive
						&ActionTaken,				// action taken
						0,							// new size, NA
						0,							// attributes, NA
						FILE_OPEN,					// do open action
						OPEN_SHARE_DENYREADWRITE |	// open shared deny writes
						OPEN_ACCESS_READWRITE,		// open rw
						NULL						// ea's
					);

			/* Assign the handle on a successful open */
			os2cdromdmd->handle = rc ? -1 : handle;
		}

	} while (0);

	if (bShowFunc) printf("<< %s::%s rc:%d\n", __FILE__, __FUNCTION__, rc);
	return rc;
}

/*****************************************************************************\
* Initialize the driver structure that holds info for 'os2cdrom.dmd'          *
* --------------------------------------------------------------------------- *
* Devices are accessed by their drive letter.                                 *
* Some DosDevIOCtl calls use a handle of -1, some use the driver handle and   *
* some use the drive handle. To hide these differences some wrapper functions *
* over DosDevIOCtl are created. To also cluster information and status, a     *
* globel structure for the 'os2cdrom.dmd' driver is used. Among the first     *
* and the number of drives handled by 'os2cdrom.dmd', there is a 26-elements  *
* array which holds information and status for drives. While of course only   *
* a few of those entries correspond to drives handled by 'os2cdrom.dmd', it   *
* does not hurt to be able to test DosDevIOCtl stuff on other drives.         *
*                                                                             *
* This function initializes that structure and it should be called when the   *
* driver is opened.                                                           *
\*****************************************************************************/
APIRET	dmd_init(struct OS2CDROMDMD *os2cdromdmd) {
	APIRET	rc = -123;
	int i = 0;

	if (bShowFunc) printf(">> %s::%s os2cdromdmd:0x%08x\n", __FILE__, __FUNCTION__, os2cdromdmd);

	/* A do-block with mutiple exit points */
	do {
		//~ break;

		/* Check for NULL pointer */
		if (os2cdromdmd == NULL) break;

		/* Iterate over array */
		for (i=0; i<26; i++) {

			/* Only unlock and close when handle is valid (not 0 or -1) */
			if (os2cdromdmd->drives[i].handle != NULL && os2cdromdmd->drives[i].handle != -1) {
				dmd_drive_unlock(os2cdromdmd, i+'A');
				dmd_drive_close(os2cdromdmd, i+'A');
			}

			/* Set state to closed and unlocked */
			os2cdromdmd->drives[i].letter = i + 'A';
			os2cdromdmd->drives[i].handle = -1;
			os2cdromdmd->drives[i].locked = FALSE;
			os2cdromdmd->drives[i].traystat_ex = 0;
			os2cdromdmd->drives[i].reset_done = FALSE;
			os2cdromdmd->drives[i].devstat_ex = 0;
		}

		/* Reset handled drives info */
		os2cdromdmd->first_drive = 0;
		os2cdromdmd->drive_count = 0;

		/* Reset supported features */
		os2cdromdmd->features = 0;

		/* We don't care about the status of any unlock or close functions called */
		rc = 0;

	} while (0);

	if (bShowFunc) printf("<< %s::%s rc:%d\n", __FILE__, __FUNCTION__, rc);
	return rc;
}

/*****************************************************************************\
* Close the driver presented by 'os2cdrom.dmd'                                *
* --------------------------------------------------------------------------- *
* The 'os2cdrom.dmd' driver handles ATAPI and USB devices.                    *
* At driver initialization, drive letters are connected to the devices found. *
*                                                                             *
* This function closes the driver.                                            *
\*****************************************************************************/
APIRET	dmd_close(struct OS2CDROMDMD *os2cdromdmd) {
	APIRET	rc = -123;
	HFILE	handle = -1;
	int i = 0;

	if (bShowFunc) printf(">> %s::%s os2cdromdmd:0x%08x\n", __FILE__, __FUNCTION__, os2cdromdmd);

	/* A do-block with mutiple exit points */
	do {
		//~ break;

		/* Check for NULL pointer */
		if (os2cdromdmd == NULL) break;

		/* Get the driver handle -- NULL or -1 indicates driver not open */
		handle = os2cdromdmd->handle;

		/* Close the driver */
		if (handle != NULL && handle != -1) {
			rc = DosClose(handle);
			/* Assign the closed handle on a successful close */
			handle = -1;
			os2cdromdmd->handle = rc ? os2cdromdmd->handle : handle;
		}

	} while (0);

	if (bShowFunc) printf("<< %s::%s rc:%d\n", __FILE__, __FUNCTION__, rc);
	return rc;
}

/*****************************************************************************\
* Query the first drive and the number of drives handled by 'os2cdrom.dmd'    *
* --------------------------------------------------------------------------- *
* Devices are accessed by their drive letter.                                 *
* The letter of the first drive handled by 'os2cdrom.dmd' depends on the      *
* 'RESERVEDDRIVELETTER=?' statement in OS/2 CONFIG.SYS. The letter of the     *
* first drive handled should be '?+1' with subsequent handled drives having   *
* a sequentially increased drive letter.                                      *
*                                                                             *
* Note that this function actually puts the *index* of the first drive in the *
* driver structure, which means drive 'A' would have index 0. The wrapper     *
* functions on the other hand, act on drive letters.                          *
\*****************************************************************************/
APIRET	dmd_query_drives(struct OS2CDROMDMD *os2cdromdmd) {
	APIRET	rc = -123;
	struct DRIVE	*drive = NULL;
	ULONG	cbParam = 0;
	ULONG	cbData = 0;
	CHAR	pbuf[512];
	CHAR	dbuf[512];
	struct	DriveLetters*	dmddl = NULL;

	if (bShowFunc) printf(">> %s::%s os2cdromdmd:0x%08x, handle:0x%08x\n", __FILE__, __FUNCTION__, os2cdromdmd, os2cdromdmd->handle);

	/* A do-block with mutiple exit points */
	do {
		//~ break;

		/* Check for NULL pointer */
		if (os2cdromdmd == NULL) break;

		/* Zero the work buffers */
		memset(pbuf, 0, sizeof(pbuf));
		memset(dbuf, 0, sizeof(dbuf));

		/* Get number of drives handled and 0-based index of first one */
		rc =	DosDevIOCtl(
					os2cdromdmd->handle,	// ioctl handle
					0x82,					// category
					0x60,					// function
					NULL,					// pParams
					0,						// cbParmLenMax
					NULL,					// pcbParmLen
					(void*) dbuf,			// pData
					sizeof(dbuf),			// cbDataLenMax
					&cbData					// pcbDataLen
				);

		/* Access the buffer using the corresponding structure */
		dmddl = (struct DriveLetters*) dbuf;

		/* Copy values to globals using received pointers */
		if (!rc) {
			os2cdromdmd->first_drive = dmddl->DriveFirst;
			os2cdromdmd->drive_count = dmddl->DriveCount;
		}

	} while (0);

	if (bShowFunc) printf("<< %s::%s rc:%d, first_drive:'%c', drive_count:%d\n", __FILE__, __FUNCTION__, rc, os2cdromdmd->first_drive+'A', os2cdromdmd->drive_count);
	return rc;
}

/*****************************************************************************\
* Query the features supported by 'os2cdrom.dmd'                              *
* --------------------------------------------------------------------------- *
* The 'os2cdrom.dmd' driver handles ATAPI and USB devices.                    *
* At driver initialization, drive letters are connected to the devices found. *
*                                                                             *
* This functions queries the features the driver supports.                    *
\*****************************************************************************/
APIRET	dmd_query_features(struct OS2CDROMDMD *os2cdromdmd) {
	APIRET	rc = -123;
	struct DRIVE	*drive = NULL;
	CHAR	pbuf[512];
	CHAR	dbuf[512];
	ULONG	cbParam = 0;
	ULONG	cbData = 0;

	if (bShowFunc) printf(">> %s::%s os2cdromdmd:0x%08x, handle:0x%08x\n", __FILE__, __FUNCTION__, os2cdromdmd, os2cdromdmd->handle);

	/* A do-block with mutiple exit points */
	do {
		//~ break;

		/* Check for NULL pointer */
		if (os2cdromdmd == NULL) break;

		/* Zero the work buffers */
		memset(pbuf, 0, sizeof(pbuf));
		memset(dbuf, 0, sizeof(dbuf));

		/* Query Driver Features */
		rc =	DosDevIOCtl(
					os2cdromdmd->handle,	// ioctl handle
					0x82,					// category
					0x63,					// function
					NULL,					// pParams
					0,						// cbParmLenMax
					&cbParam,				// pcbParmLen
					dbuf,					// pData
					sizeof(dbuf),			// cbDataLenMax
					&cbData					// pcbDataLen
				);

		/* Store feature flags if successful */
		os2cdromdmd->features = rc ? os2cdromdmd->features : (ULONG) ((ULONG*)dbuf)[0];

		DumpPara((PCHAR) dbuf);
		printf("\n");

	} while (0);

	if (bShowFunc) printf("<< %s::%s rc:%d\n", __FILE__, __FUNCTION__, rc);
	return rc;
}

/*****************************************************************************\
* Open a drive as a DASD device                                               *
* --------------------------------------------------------------------------- *
* Devices are accessed by their drive letter.                                 *
* Opening a drive as DASD results in de volume represented by that drive to   *
* be accesible as a big file. The returned handle is used by DosDevIOCtl.     *
*                                                                             *
* Note that this is not an 'os2cdrom.dmd' specific DosDevIOCtl call but a     *
* regular DosOpen API call with DASD flags set.                               *
\*****************************************************************************/
APIRET	dmd_drive_open(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter) {
	APIRET	rc = -123;
	struct DRIVE	*drive = NULL;
	ULONG	ulAction = 0;
	CHAR	buf[512];

	if (bShowFunc) printf(">> %s::%s drive_letter:'%c'\n", __FILE__, __FUNCTION__, drive_letter);

	/* A do-block with mutiple exit points */
	do {
		//~ break;

		/* Check for NULL pointer */
		if (os2cdromdmd == NULL) break;

		/* Check for valid drive letter */
		if (drive_letter < 'A' || drive_letter > 'Z') break;

		/* Compose pointer to drive information */
		drive = &os2cdromdmd->drives[drive_letter - 'A'];

		/* Set the handle to -1 if it is NULL */
		drive->handle = drive->handle ? drive->handle : -1;

		/* Don't open again if already open, just return success, existing handle assumed valid */
		rc = 0;
		if (drive->handle != -1) break;

		/* Prepare drive-letter as string */
		buf[0] = drive->letter;
		buf[1] = ':';
		buf[2] = '\0';

		/* Open the drive in DASD mode */
		rc =	DosOpen(
					(PSZ) buf,					// drive-letter ("?:") to open as DASD
					&drive->handle,				// handle to receive for ioctl
					&ulAction,					// action taken
					0,							// new size -- not applicable
					FILE_READONLY,				// file attributes -- not applicable
					OPEN_ACTION_OPEN_IF_EXISTS,	// the drive should exist
					OPEN_FLAGS_DASD |			// open as DASD making the whole volume one big file
					OPEN_FLAGS_NO_CACHE |		// we don't want caching for now
					OPEN_SHARE_DENYREADWRITE |	// we want exclusive access
					OPEN_ACCESS_READONLY,		// we want ro access for now -- might need to be changed
					NULL						// eas -- not applicable
				);

		/* Set handle to -1 if open failed */
		drive->handle = rc ? -1 : drive->handle;

	} while (0);

	if (bShowFunc) printf("<< %s::%s handle:0x%08x, rc:%d\n", __FILE__, __FUNCTION__, drive ? drive->handle : 0x12345678, rc);
	return rc;
}

/*****************************************************************************\
* Lock a drive for subsequent access                                          *
* --------------------------------------------------------------------------- *
* Devices are accessed by their drive letter.                                 *
* Some funtions, like redetermining the media, require a drive to be locked.  *
* This function does that.                                                    *
*                                                                             *
* Note that this is not an 'os2cdrom.dmd' specific DosDevIOCtl call but a     *
* regular DosDevIOCtl call.                                                   *
*                                                                             *
* Also note that locking a drive multiple times does not require unlocking it *
* the same number of times, meaning there is no lock count involved.          *
*                                                                             *
* Also note that closing a locked drive will not unlock it. Opening the drive *
* again would open it in a locked state.                                      *
\*****************************************************************************/
APIRET	dmd_drive_lock(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter) {
	APIRET	rc = -123;
	struct DRIVE	*drive = NULL;
	ULONG	cbParam = 0;
	ULONG	cbData = 0;

	if (bShowFunc) printf(">> %s::%s drive_letter:'%c'\n", __FILE__, __FUNCTION__, drive_letter);

	/* A do-block with mutiple exit points */
	do {
		//~ break;

		/* Check for NULL pointer */
		if (os2cdromdmd == NULL) break;

		/* Check for valid drive letter */
		if (drive_letter < 'A' || drive_letter > 'Z') break;

		/* Compose pointer to drive information */
		drive = &os2cdromdmd->drives[drive_letter - 'A'];

		/* Lock the drive */
		rc =	DosDevIOCtl(
					drive->handle,		// ioctl handle
					0x08,				// category
					0x00,				// function
					NULL,				// pParams
					0,					// cbParmLenMax
					&cbParam,			// pcbParmLen
					NULL,				// pData
					0,					// cbDataLenMax
					&cbData				// pcbDataLen
				);

		/* Update lock status on success */
		drive->locked = rc ? FALSE : TRUE;

	} while (0);

	if (bShowFunc) printf("<< %s::%s rc:%d\n", __FILE__, __FUNCTION__, rc);
	return rc;
}

/*****************************************************************************\
* Unlock a drive when accessing it is finished                                *
* --------------------------------------------------------------------------- *
* Devices are accessed by their drive letter.                                 *
* Some funtions, like redetermining the media, require a drive to be locked.  *
* This function unlocks the drive after access to it has finished.            *
*                                                                             *
* Note that this is not an 'os2cdrom.dmd' specific DosDevIOCtl call but a     *
* regular DosDevIOCtl call.                                                   *
*                                                                             *
* Also note that unlocking a drive once is enough and unlocking multiple      *
* times is not an error, meaning there is no lock count involved.             *
\*****************************************************************************/
APIRET	dmd_drive_unlock(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter) {
	APIRET	rc = -123;
	struct DRIVE	*drive = NULL;
	ULONG	cbParam = 0;
	ULONG	cbData = 0;

	if (bShowFunc) printf(">> %s::%s drive_letter:'%c'\n", __FILE__, __FUNCTION__, drive_letter);

	/* A do-block with mutiple exit points */
	do {
		//~ break;

		/* Check for NULL pointer */
		if (os2cdromdmd == NULL) break;

		/* Check for valid drive letter */
		if (drive_letter < 'A' || drive_letter > 'Z') break;

		/* Compose pointer to drive information */
		drive = &os2cdromdmd->drives[drive_letter - 'A'];

		/* Unlock the drive */
		rc =	DosDevIOCtl(
					drive->handle,		// ioctl handle
					0x08,				// category
					0x01,				// function
					NULL,				// pParams
					0,					// cbParmLenMax
					&cbParam,			// pcbParmLen
					NULL,				// pData
					0,					// cbDataLenMax
					&cbData				// pcbDataLen
				);

		/* Update lock status on success */
		drive->locked = rc ? drive->locked : FALSE;

	} while (0);

	if (bShowFunc) printf("<< %s::%s rc:%d\n", __FILE__, __FUNCTION__, rc);
	return rc;
}

/*****************************************************************************\
* Close a drive when accessing it is finished                                 *
* --------------------------------------------------------------------------- *
* Devices are accessed by their drive letter.                                 *
* This function closes the drive after access to it has finished.             *
*                                                                             *
* Note that this is not an 'os2cdrom.dmd' specific DosDevIOCtl call but a     *
* regular DosOpen API call.                                                   *
*                                                                             *
* Also note that closing a locked drive will not unlock it. Opening the drive *
* again would open it in a locked state.                                      *
\*****************************************************************************/
APIRET	dmd_drive_close(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter) {
	APIRET	rc = -123;
	struct DRIVE	*drive = NULL;

	if (bShowFunc) printf(">> %s::%s drive_letter:'%c'\n", __FILE__, __FUNCTION__, drive_letter);

	/* A do-block with mutiple exit points */
	do {
		//~ break;

		/* Check for NULL pointer */
		if (os2cdromdmd == NULL) break;

		/* Check for valid drive letter */
		if (drive_letter < 'A' || drive_letter > 'Z') break;

		/* Compose pointer to drive information */
		drive = &os2cdromdmd->drives[drive_letter - 'A'];

		/* Set the handle to -1 if it is NULL */
		drive->handle = drive->handle ? drive->handle : -1;

		/* Don't close again if already closed, just return success */
		rc = 0;
		if (drive->handle == -1) break;

		/* Close the DASD opened drive */
		rc = DosClose(drive->handle);

		/* Indicate drive is closed */
		drive->handle = -1;

		/* Closing is always successful, even when the handle was invalid */
		rc = 0;

	} while (0);

	if (bShowFunc) printf("<< %s::%s handle:0x%08x, rc:%d\n", __FILE__, __FUNCTION__, drive ? drive->handle : 0x12345678, rc);
	return rc;
}

/*****************************************************************************\
* Redetermine the media in a drive                                            *
* --------------------------------------------------------------------------- *
* Devices are accessed by their drive letter.                                 *
* This function tries to refresh the media information. The drive needs to be *
* locked and a readable medium needs to be present for this function to       *
* succeed.                                                                    *
*                                                                             *
* Note that this is not an 'os2cdrom.dmd' specific DosDevIOCtl call but a     *
* regular DosDevIOCtl call.                                                   *
\*****************************************************************************/
APIRET	dmd_drive_redetermine_media(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter) {
	APIRET	rc = -123;
	struct DRIVE	*drive = NULL;
	ULONG	cbParam = 0;
	ULONG	cbData = 0;

	if (bShowFunc) printf(">> %s::%s drive_letter:'%c'\n", __FILE__, __FUNCTION__, drive_letter);

	/* A do-block with mutiple exit points */
	do {
		//~ break;

		/* Check for NULL pointer */
		if (os2cdromdmd == NULL) break;

		/* Check for valid drive letter */
		if (drive_letter < 'A' || drive_letter > 'Z') break;

		/* Compose pointer to drive information */
		drive = &os2cdromdmd->drives[drive_letter - 'A'];

		/* Redetermine Media */
		rc =	DosDevIOCtl(
					drive->handle,		// ioctl handle
					0x08,				// category
					0x02,				// function
					NULL,				// pParams
					0,					// cbParmLenMax
					&cbParam,			// pcbParmLen
					NULL,				// pData
					0,					// cbDataLenMax
					&cbData				// pcbDataLen
				);

	} while (0);

	if (bShowFunc) printf("<< %s::%s rc:%d\n", __FILE__, __FUNCTION__, rc);
	return rc;
}

/*****************************************************************************\
* Execute a SCSI-Command against 'os2cdrom.dmd'                               *
* --------------------------------------------------------------------------- *
* Devices are accessed by their drive letter.                                 *
* This function executes a SCSI-Command against the 'cd-rom2$' device.        *
* SCSI-Commands are described by a 'Command Descriptor Block' (CDB), and the  *
* maximum size of a CDB that 'os2cdrom.dmd' can handle is 16 bytes.           *
*                                                                             *
* In this version a drive *handle* is used to select the device to act upon.  *
*                                                                             *
* Note that this is an 'os2cdrom.dmd' specific DosDevIOCtl call.              *
\*****************************************************************************/
//! OUT OF SYNC WITH EXEC2
APIRET	dmd_drive_scsi_exec(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter, UCHAR *cmd_buf, ULONG cmd_len, UCHAR *result_buf, ULONG result_len, UCHAR *sense_buf, ULONG sense_len) {
	APIRET	rc = -123;
	struct DRIVE	*drive = NULL;
	ULONG	cbParam = 0;
	ULONG	cbData = 0;
	CHAR	pbuf[512];
	CHAR	dbuf[512];
	struct	ExecCMD*	ecmd;
	struct	RetStatus*	sretstat;

	if (bShowFunc) printf(">> %s::%s drive_letter:'%c'\n", __FILE__, __FUNCTION__, drive_letter);

	/* Display Parameters */
	if (bLibscgDebug) {
		printf(
			"   cmd:0x%02x"
			"@'%c', "
			"cmd_buf:0x%08x, "
			"cmd_len:%d, "
			"result_buf:0x%08x, "
			"result_len:%d, "
			"sense_buf:0x%08x, "
			"sense_len:%d\n",
			cmd_buf[0],
			drive_letter,
			cmd_buf,
			cmd_len,
			result_buf,
			result_len,
			sense_buf,
			sense_len
		);
	}

	/* A do-block with mutiple exit points */
	do {
		//~ break;

		/* Check for NULL pointer */
		if (os2cdromdmd == NULL) break;

		/* Check for valid drive letter */
		if (drive_letter < 'A' || drive_letter > 'Z') break;

		/* Compose pointer to drive information */
		drive = &os2cdromdmd->drives[drive_letter - 'A'];

		/* Zero the work buffers */
		memset(pbuf, 0, sizeof(pbuf));
		memset(dbuf, 0, sizeof(dbuf));

		/* Address param buffer as structure */
		ecmd = (struct ExecCMD*) pbuf;

		/* Parameters */
		ecmd->ID_code = '10DC';						// 'CD01'
		ecmd->data_length = result_len;				// returned data from scsi-command, if retstat desired it is placed after this
		ecmd->cmd_length = cmd_len;					// seems length of the scsi-command, a value >16 returns 65299
		ecmd->flags = 0x00;							// 0x04 is also return status
		memcpy(ecmd->cmd_buffer, cmd_buf, cmd_len);	// copy scsi command
		ecmd->cmd_timeout = 0;

		/* Execute SCSI Command */
		rc =	DosDevIOCtl(
					drive->handle,								// ioctl handle
					0x80,										// category
					0x7a,										// function
					(void*) pbuf,								// pParams
					sizeof(pbuf),								// cbParmLenMax
					&cbParam,									// pcbParmLen
					result_len ? (void*) result_buf : NULL,		// pData
					result_len,									// cbDataLenMax
					&cbData										// pcbDataLen
				);

		/* Address data buffer as structure */
		sretstat = (struct RetStatus*) dbuf + 256;

		/* Dump the return data */
		//~ DumpMem((PCHAR) result_buf, 512/16);

		//~ memcpy(result_buf, dbuf, result_len);

		/* Print some info */
		if (bLibscgDebug) {
			printf(
				"sensekey:%08X, asc_code:%08X, ascq_code:%08X\n",
				(unsigned) sretstat->sense_key,
				(unsigned) sretstat->asc_code,
				(unsigned) sretstat->ascq_code
			);
			printf("rc:%d, cbParam:%d, cbData:%d\n", rc, (unsigned) cbParam, (unsigned) cbData);
		}
	} while (0);

	if (bShowFunc) printf("<< %s::%s rc:%d\n", __FILE__, __FUNCTION__, rc);
	return rc;
}

/*****************************************************************************\
* Execute a SCSI-Command against 'os2cdrom.dmd'                               *
* --------------------------------------------------------------------------- *
* Devices are accessed by their drive letter.                                 *
* This function executes a SCSI-Command against the 'cd-rom2$' device.        *
* SCSI-Commands are described by a 'Command Descriptor Block' (CDB), and the  *
* maximum size of a CDB that 'os2cdrom.dmd' can handle is 16 bytes.           *
*                                                                             *
* In this version a drive *letter* is used to select the device to act upon.  *
*                                                                             *
* Note that this is an 'os2cdrom.dmd' specific DosDevIOCtl call.              *
\*****************************************************************************/
APIRET	dmd_drive_scsi_exec2(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter, UCHAR *cmd_buf, ULONG cmd_len, UCHAR *result_buf, ULONG result_len, UCHAR *sense_buf, ULONG sense_len) {
	APIRET	rc = -123;
	struct DRIVE	*drive = NULL;
	ULONG	cbParam = 0;
	ULONG	cbData = 0;
	CHAR	pbuf[512];
	CHAR	dbuf[512];
	PCHAR	rbuf = NULL;
	struct	ExecCMD2*	ecmd;
	struct	RetStatus*	sretstat;

	if (bShowFunc|1) printf(">> %s::%s drive_letter:'%c'\n", __FILE__, __FUNCTION__, drive_letter);

	/* Display Parameters */
	if (bLibscgDebug) {
		printf(
			"   cmd:0x%02x"
			"@'%c', "
			"cmd_buf:0x%08x, "
			"cmd_len:%d, "
			"result_buf:0x%08x, "
			"result_len:%d, "
			"sense_buf:0x%08x, "
			"sense_len:%d\n",
			cmd_buf[0],
			drive_letter,
			cmd_buf,
			cmd_len,
			result_buf,
			result_len,
			sense_buf,
			sense_len
		);
	}

	/* A do-block with mutiple exit points */
	do {
		//~ break;

		/* Check for NULL pointer */
		if (os2cdromdmd == NULL) break;

		/* Check for valid drive letter */
		if (drive_letter < 'A' || drive_letter > 'Z') break;

		/* Compose pointer to drive information */
		drive = &os2cdromdmd->drives[drive_letter - 'A'];

		/* Zero the work buffers */
		memset(pbuf, 0, sizeof(pbuf));
		memset(dbuf, 0, sizeof(dbuf));

		/* Address param buffer as structure */
		ecmd = (struct ExecCMD2*) pbuf;

		/* Parameters */
		ecmd->unit = drive_letter - 'A';			// 'CD01'
		ecmd->data_length = result_len;				// returned data from scsi-command, if retstat desired it is placed after this
		ecmd->cmd_length = cmd_len;					// seems length of the scsi-command, a value >16 returns 65299
		ecmd->flags = 0x04;							// 0x04 is also return status
		memcpy(ecmd->cmd_buffer, cmd_buf, cmd_len);	// copy scsi command
		ecmd->cmd_timeout = 0;

		if (result_len == 0 && result_buf == NULL) {
			rbuf = dbuf;
		}
		else {
			rbuf = result_buf;
		}

		//! POTENTIAL BUFFER OVERRUN
		memset(rbuf, 0, 512);

		if (bLibscgDebug) printf("rbuf:0x%08x, dbuf:0x%08x, result_buf:0x%08x, result_len:%d\n", rbuf, dbuf, result_buf, result_len);

		/* Execute SCSI Command */
		rc =	DosDevIOCtl(
					os2cdromdmd->handle,						// ioctl handle
					0x82,										// category
					0x7a,										// function
					(void*) pbuf,								// pParams
					sizeof(pbuf),								// cbParmLenMax
					&cbParam,									// pcbParmLen
					rbuf,										// pData
					result_len ? result_len + sizeof(struct	RetStatus) : sizeof(dbuf),		// cbDataLenMax
					&cbData										// pcbDataLen
				);

		if (bLibscgDebug) {
			DumpMem((PCHAR) rbuf, 4);
		}

		/* Address data buffer as structure */
		sretstat = (struct RetStatus*) (rbuf + result_len);

		/* Print sense info */
		if (bLibscgDebug) {
			printf(
				"sretstat:0x%08X, sensekey:0x%02X, asc_code:0x%02X, ascq_code:0x%02X\n",
				sretstat,
				sretstat->sense_key,
				sretstat->asc_code,
				sretstat->ascq_code
			);
		}

		if (bLibscgDebug) printf("DMD-SCSI-EXEC2:    rc:%d\n", rc);

		/* Get Sense Information */
		do {
			//~ break;
			APIRET	rcT = -123;
			CHAR	ibuf[512];
			CHAR	obuf[512];
			ULONG	cbParamT = 0;
			ULONG	cbDataT = 0;
			struct	ExecCMD2*	ecmdT;
			struct	RetStatus*	sretstatT;

			/* Zero block local work buffers */
			memset(ibuf, 0, sizeof(ibuf));
			memset(obuf, 0, sizeof(obuf));

			/* Compose pointer to construct IOCtl SCSI Command */
			ecmdT = (struct ExecCMD2*) ibuf;

			ecmdT->unit = drive_letter - 'A';
			ecmdT->data_length = 252;				// returned data from scsi-command, if retstat desired it is placed after this
			ecmdT->cmd_length = 6;					// seems length of the scsi-command, a value >16 returns 65299
			ecmdT->flags = 0x00;							// 0x04 is also return status

			/* Zero the CDB */
			memset(ecmdT->cmd_buffer, 0, 16);

			/* REQUEST SENSE COMMAND */
			ecmdT->cmd_buffer[0] = 0x03;
			ecmdT->cmd_buffer[4] = 252;

			ecmdT->cmd_timeout = 0;

			rcT =	DosDevIOCtl(
						os2cdromdmd->handle,						// ioctl handle
						0x82,										// category
						0x7a,										// function
						(void*) ibuf,								// pParams
						sizeof(ibuf),								// cbParmLenMax
						&cbParamT,									// pcbParmLen
						(void*) obuf,								// pData
						sizeof(obuf),								// cbDataLenMax
						&cbDataT									// pcbDataLen
					);

			if (bLibscgDebug) {
				DumpMem((PCHAR) obuf, 32/16);
				printf("DMD-SCSI-SENSE:   rcT:%d\n", rcT);
			}

			/* Copy sense to buffer and merge return status of actual command */
			if (sretstat->sense_key || sretstat->asc_code || sretstat->ascq_code) {
				if (bLibscgDebug) printf("BAD SENSE sense_buf:0x%08x, obuf:0x%08x\n", sense_buf, obuf);
				memcpy(sense_buf, obuf, 64);
				sense_buf[02] = sretstat->sense_key;
				sense_buf[12] = sretstat->asc_code;
				sense_buf[13] = sretstat->ascq_code;
			}

		} while (0);

		/* Investigate 'GET CONFIGURATION' which fails on USB devices */
		do {
			break;
			//~ APIRET	rc = -456;

			/* Break from block if not 'GET CONFIGURATION' command */
			if (cmd_buf[0] != 0x46) break;

			printf("\n");
			printf("<< GET CONFIGURATION :: result_len:%d, rc:%d >>\n", result_len, rc);
			printf("[IN]\n");
			DumpMem((PCHAR) ecmd->cmd_buffer, 1);
			printf("[OUT]\n");
			DumpMem((PCHAR) rbuf, 4);
			printf("[SENSE]\n");
			DumpMem((PCHAR) sense_buf, 1);
			printf(
				"sretstat:0x%08X, sensekey:0x%02X, asc_code:0x%02X, ascq_code:0x%02X\n",
				sretstat,
				sretstat->sense_key,
				sretstat->asc_code,
				sretstat->ascq_code
			);
			printf("\n");

		} while (0);

	} while (0);

	if (bShowFunc) printf("<< %s::%s rc:%d\n", __FILE__, __FUNCTION__, rc);
	return rc;
}

/*****************************************************************************\
* Process a SCSI Request Block against 'os2cdrom.dmd'                         *
* --------------------------------------------------------------------------- *
* Devices are accessed by their drive letter.                                 *
* For the 'aspirout.sys' driver, SCSI Commands are passes embedded in a SCSI  *
* Request Block, which is also used to return results and status.             *
*                                                                             *
* The 'os2cdrom.dmd' driver only accepts bare SCSI Commands, which cannot be  *
* larger than 16 bytes. To interface with the ASPI oriented upper layers,     *
* this function disects the incoming SRB, passes the embedded SCSI Command to *
* the * 'cd-rom2' driver, waits for it to be processed, and constructs an SRB *
* that is returned to the upper layer. It tends to act a the level of the     *
* ASPI DosDevIOCtl cat:0x92, func:0x02 call.                                  *
*                                                                             *
* This function mimics processing of SRBs against the 'os2cdrom.dmd' driver.  *
\*****************************************************************************/
APIRET	dmd_drive_scsi_process_srb(struct OS2CDROMDMD *os2cdromdmd, SRB *srb, ULONG srb_len) {
	APIRET	rc = -123;
	UCHAR	sbuf[256];
	UCHAR	cmd = srb ? srb->u.cmd.cdb_st[0] : 0x00;
	CHAR	drive_letter = os2cdromdmd && srb ? os2cdromdmd->first_drive + srb->u.cmd.target + 'A' - 1 : 0x00;
	struct DRIVE	*drive = NULL;

	if (bShowFunc) printf("\n");
	if (bShowFunc) printf(">> %s::%s srb:0x%08x, srb_len:%d, cmd:0x%02x\n", __FILE__, __FUNCTION__, srb, srb_len, cmd);

	if (bLibscgDebug) {
		printf("--------> cmd:0x%02x\n", cmd);
		printf("--------> cmd.target:%d -- drive '%c'\n", srb->u.cmd.target, os2cdromdmd->first_drive + srb->u.cmd.target + 'A' - 1);
		printf("--------> cmd.cdb_len:%d\n", srb->u.cmd.cdb_len);
		printf("--------> cmd.cmd.data_ptr:%08x\n", srb->u.cmd.data_ptr);
		printf("--------> cmd.cmd.data_len:%d\n", srb->u.cmd.data_len);
	}


	/* Check for valid drive letter */
	//~ if (drive_letter < 'A' || drive_letter > 'Z') break;

	/* Compose pointer to drive information */
	drive = &os2cdromdmd->drives[drive_letter - 'A'];


	/*
	// Reset the drive on the very first 'TEST UNIT'.
	// If this succeeds, the 'reset_done' flag is set.
	// Resetting a drive is needed for the (first?) 'TEST UNIT' command
	// to succeed.
	*/
	do {
		break;
		APIRET	rc1 = -456;		// rc for extended devstat
		APIRET	rc2 = -456;		// rc for open
		APIRET	rc3 = -456;		// rc for reset
		APIRET	rc4 = -456;		// rc for close
		ULONG	retry = 20;		// retry count
		ULONG	delay = 1000;	// delay -- 1000 = 1 sec

		/* Break from block if not 'TEST UNIT' command */
		if (cmd != 0x00) break;

		/* Print current reset state */
		if (bLibscgDebug|1) printf("reset_done:%d\n", drive->reset_done);

		/* Break from block if reset is already done */
		if (drive->reset_done) break;

		rc1 = dmd_drive_media_get_lock_status(os2cdromdmd, drive_letter);
		if (bLibscgDebug|1) printf("lockstat:%d\n", drive->lockstat);

		/* Get the extended device status */
		rc1 = dmd_drive_query_device_status_ex(os2cdromdmd, drive_letter);

		/* Break from block if the tray is open */
		if (bLibscgDebug|1) printf("tray_open:%d\n", drive->tray_open);
		if (drive->tray_open) break;

		/* Door is closed, wait one second to prevent spurious ready state */
		DosSleep(1000);

		/* Get the extended device status */
		rc1 = dmd_drive_query_device_status_ex(os2cdromdmd, drive_letter);

		/* If a medium is not present, ready_state will be 0, if so, break from block */
		if (bLibscgDebug|1) printf("ready_state:%d\n", drive->ready_state);
		if (drive->ready_state == 0) break;

		/* Wait for the drive to become ready */
		do {
			printf("ready_state:%d, retry:%d\n", drive->ready_state, retry);
			rc1 = dmd_drive_query_device_status_ex(os2cdromdmd, drive_letter);
			if (drive->ready_state == 3) break;
			printf("delay\n");
			DosSleep(delay);
			retry--;
		} while (retry > 0);

		/* If ready_state not 3, break from block -- should not happen */
		if (bLibscgDebug|1) printf("ready_state:%d\n", drive->ready_state);
		if (drive->ready_state != 3) break;

		/* Should now be possible to open drive */
		rc2 = dmd_drive_open(os2cdromdmd, drive_letter);
		if (bLibscgDebug|1) printf("dmd_drive_open->rc=%d\n", rc2);

		/* Reset the drive */
		rc3 = dmd_drive_cdrom_reset(os2cdromdmd, drive_letter);
		if (bLibscgDebug|1) printf("dmd_drive_cdrom_reset->rc:%d\n", rc3);

		/* Redetermine Media -- work around blank cd(rw) bug */
		do {
			APIRET	rc = -456;
			rc = dmd_drive_lock(os2cdromdmd, drive_letter);
			rc = dmd_drive_redetermine_media(os2cdromdmd, drive_letter);
			if (rc == ERROR_SECTOR_NOT_FOUND) {
				rc = dmd_drive_close(os2cdromdmd, drive_letter);
				rc = dmd_drive_open(os2cdromdmd, drive_letter);
			}
			rc = dmd_drive_unlock(os2cdromdmd, drive_letter);
		} while (0);

		/* Close the drive */
		rc4 = dmd_drive_close(os2cdromdmd, drive_letter);
		if (bLibscgDebug|1) printf("dmd_drive_close->rc:%d\n", rc4);

		/* Set the flag if all calls above succeeded, clear otherwise */
		drive->reset_done = (rc1 || rc2 || rc3 || rc4) ? FALSE : TRUE;
	} while (0);


	/*
	// Redertermine Media if this is the SCSI  'UNLOCK' command.
	// This is the last command sent.
	*/
	do {
		//~ break;
		APIRET	rc = -456;

		/* Break from block if not 'PREVENT/ALLOW MEDIUM REMOVAL' command */
		if (cmd != 0x1e) break;

		/* Break out if not unlock */
		if (srb->u.cmd.cdb_st[4] != 0x00) break;

		if (bLibscgDebug|1) printf("REDETERMINING MEDIA FOR '%c'\n", drive_letter);

		/* Redetermine the media */
		rc = dmd_drive_open(os2cdromdmd, drive_letter);
		rc = dmd_drive_lock(os2cdromdmd, drive_letter);
		rc = dmd_drive_redetermine_media(os2cdromdmd, drive_letter);

		/* Workaround for redetermine media that closes drives when media is blank cd(rw) */
		if (rc == ERROR_SECTOR_NOT_FOUND) {
			rc = dmd_drive_close(os2cdromdmd, drive_letter);
			rc = dmd_drive_open(os2cdromdmd, drive_letter);
		}

		/* Unlock and Close */
		rc = dmd_drive_unlock(os2cdromdmd, drive_letter);
		rc = dmd_drive_close(os2cdromdmd, drive_letter);
	} while (0);


	/* Zero sense buffer */
	memset(sbuf, 0, sizeof(sbuf));


	/* Execute the SCSI Command */
	rc =	dmd_drive_scsi_exec2(
				os2cdromdmd,			// pointer to driver structure
				drive_letter,			// drive-letter of device to process scsi-command
				srb->u.cmd.cdb_st,		// scsi command
				srb->u.cmd.cdb_len,		// length of scsi command
				os2cdromdmd->buffer,	// pointer to buffer for result
				srb->u.cmd.data_len,	// expected length of result
				sbuf,					// poiter to sense buffer
				sizeof(sbuf)			// size of sense buffer
			);

	if (bLibscgDebug) {
		printf("SENSEBUF:\n");
		DumpMem((PCHAR) sbuf, 2);
	}

	/* Copy sense information to SRB -- after SCSI command */
	memcpy((srb->u.cmd.cdb_st + srb->u.cmd.cdb_len), sbuf, 18);

	/* Set status depending on success of IOCtl */
	if (!rc) {
		srb->status = 1;
		srb->u.cmd.data_ptr = srb->u.cmd.data_len ? (unsigned long) os2cdromdmd->buffer : (unsigned long) NULL;
	}
	else {
		srb->status = 130;	//! Check if this value is appropriate -- means device not present
	}

	/* Copy sense key to srb status */
	srb->u.cmd.target_status = sbuf[02];

	/* Special Post Processing */
	switch (cmd) {
		/* TEST UNIT */
		case 0x00:
			/* Set SRB status to 4 -- fixes media present requirement for scanbus */
			srb->status = rc == 65282 ? 4 : srb->status;
			rc = 0;
			break;
		/* MODE SELECT G1 */
		case 0x55:
			//~ break;
			srb->status = 1;
			rc = 0;
			break;
		/* READ BUFFER */
		case 0x3c:
			//~ break;
			srb->status = 1;
			rc = 0;
			break;
		/* START/STOP UNIT */
		case 0x1b:
			//~ break;
			srb->status = 1;
			rc = 0;
			break;
		/* READ TOC */
		case 0x43:
			//~ break;
			srb->status = 1;
			rc = 0;
			break;
		/* SEND OPC */
		case 0x54:
			//~ break;
			srb->status = 1;
			rc = 0;
			break;
		/* SEND CUE SHEET */
		case 0x5d:
			//~ break;
			srb->status = 1;
			srb->u.cmd.target_status = 0;
			memset((srb->u.cmd.cdb_st + srb->u.cmd.cdb_len), 0, 18);
			rc = 0;
			break;
		/* INQUIRY */
		case 0x12:
			break;
			printf("\n");
			DumpSRB(srb);
			printf("\n");
			srb->status = rc == 65282 ? 130 : srb->status;
			rc = 0;
			break;
	}

	if (bShowFunc) printf("<< %s::%s rc:%d\n", __FILE__, __FUNCTION__, rc);
	if (bShowFunc) printf("\n");
	return rc;
}

/*****************************************************************************\
* Lock the tray of a removable device                                         *
* --------------------------------------------------------------------------- *
* Devices are accessed by their drive letter.                                 *
* Locking a tray prevents a user from manually ejecting the media by pressing *
* the eject button on the device. This kind of locking should not be confused *
* with DASD drive locking.                                                    *
*                                                                             *
* Note that this is not an 'os2cdrom.dmd' specific DosDevIOCtl call but a     *
* regular DosDevIOCtl call.                                                   *
*                                                                             *
* Also note that locking a drive multiple times does not require unlocking it *
* the same number of times, meaning there is no lock count involved.          *
*                                                                             *
* Also note that programmatically ejecting a locked device does not work.     *
\*****************************************************************************/
APIRET	dmd_drive_media_lock(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter) {
	APIRET	rc = -123;
	struct DRIVE	*drive = NULL;
	CHAR	pbuf[512];
	CHAR	dbuf[512];
	ULONG	cbParam = 0;
	ULONG	cbData = 0;

	if (bShowFunc) printf(">> %s::%s drive_letter:'%c'\n", __FILE__, __FUNCTION__, drive_letter);

	/* A do-block with mutiple exit points */
	do {
		//~ break;

		/* Check for NULL pointer */
		if (os2cdromdmd == NULL) break;

		/* Check for valid drive letter */
		if (drive_letter < 'A' || drive_letter > 'Z') break;

		/* Compose pointer to drive information */
		drive = &os2cdromdmd->drives[drive_letter - 'A'];

		/* Zero the work buffers */
		memset(pbuf, 0, sizeof(pbuf));
		memset(dbuf, 0, sizeof(dbuf));

		/* Parameters */
		pbuf[0] = 0x01;
		pbuf[1] = drive_letter - 'A';

		/* Lock */
		rc =	DosDevIOCtl(
					-1,					// ioctl handle
					0x08,				// category
					0x40,				// function
					pbuf,				// pParams
					sizeof(pbuf),		// cbParmLenMax
					&cbParam,			// pcbParmLen
					dbuf,				// pData
					sizeof(dbuf),		// cbDataLenMax
					&cbData				// pcbDataLen
				);

		/* Set lock status for device on success */
		drive->traystat_ex = rc ? drive->traystat_ex : (ULONG) ((USHORT*) dbuf)[0];

	} while (0);

	if (bShowFunc) printf("<< %s::%s status:0x%08x, rc:%d\n", __FILE__, __FUNCTION__, drive ? drive->traystat_ex : 0xffffffff, rc);
	return rc;
}

/*****************************************************************************\
* Get the lock status and other attributes of a device                        *
* --------------------------------------------------------------------------- *
* Devices are accessed by their drive letter.                                 *
* Besides getting an indication whether the tray of a device is locked, this  *
* function also detects if a medium is present.                               *
*                                                                             *
* Note that this is not an 'os2cdrom.dmd' specific DosDevIOCtl call but a     *
* regular DosDevIOCtl call.                                                   *
\*****************************************************************************/
APIRET	dmd_drive_media_get_lock_status(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter) {
	APIRET	rc = -123;
	struct DRIVE	*drive = NULL;
	CHAR	pbuf[512];
	CHAR	dbuf[512];
	ULONG	cbParam = 0;
	ULONG	cbData = 0;

	if (bShowFunc) printf(">> %s::%s drive_letter:'%c'\n", __FILE__, __FUNCTION__, drive_letter);

	/* A do-block with mutiple exit points */
	do {
		//~ break;

		/* Check for NULL pointer */
		if (os2cdromdmd == NULL) break;

		/* Check for valid drive letter */
		if (drive_letter < 'A' || drive_letter > 'Z') break;

		/* Compose pointer to drive information */
		drive = &os2cdromdmd->drives[drive_letter - 'A'];

		/* Zero the work buffers */
		memset(pbuf, 0, sizeof(pbuf));
		memset(dbuf, 0, sizeof(dbuf));

		/* Parameters */
		pbuf[0] = 0x01;
		pbuf[1] = drive_letter - 'A';

		/* Lock Status */
		rc =	DosDevIOCtl(
					-1,					// ioctl handle
					0x08,				// category
					0x66,				// function
					pbuf,				// pParams
					sizeof(pbuf),		// cbParmLenMax
					&cbParam,			// pcbParmLen
					dbuf,				// pData
					sizeof(dbuf),		// cbDataLenMax
					&cbData				// pcbDataLen
				);

		/* Set lock status for device on success */
		drive->traystat_ex = rc ? drive->traystat_ex : (ULONG) ((USHORT*) dbuf)[0];

	} while (0);

	if (bShowFunc) printf("<< %s::%s status:0x%08x, rc:%d\n", __FILE__, __FUNCTION__, drive ? drive->traystat_ex : 0xffffffff, rc);
	return rc;
}

/*****************************************************************************\
* Unlock the tray of a removable device                                       *
* --------------------------------------------------------------------------- *
* Devices are accessed by their drive letter.                                 *
* Unlocking a tray enables a user to manually eject the media by pressing     *
* the eject button on the device. This kind of unlocking should not be        *
* confused with DASD drive unlocking.                                         *
*                                                                             *
* Note that this is not an 'os2cdrom.dmd' specific DosDevIOCtl call but a     *
* regular DosDevIOCtl call.                                                   *
*                                                                             *
* Also note that unlocking a drive multiple times does not require unlocking  *
* it the same number of times, meaning there is no lock count involved.       *
*                                                                             *
* Also note that programmatically ejecting is emabled again.                  *
\*****************************************************************************/
APIRET	dmd_drive_media_unlock(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter) {
	APIRET	rc = -123;
	struct DRIVE	*drive = NULL;
	CHAR	pbuf[512];
	CHAR	dbuf[512];
	ULONG	cbParam = 0;
	ULONG	cbData = 0;

	if (bShowFunc) printf(">> %s::%s drive_letter:'%c'\n", __FILE__, __FUNCTION__, drive_letter);

	/* A do-block with mutiple exit points */
	do {
		//~ break;

		/* Check for NULL pointer */
		if (os2cdromdmd == NULL) break;

		/* Check for valid drive letter */
		if (drive_letter < 'A' || drive_letter > 'Z') break;

		/* Compose pointer to drive information */
		drive = &os2cdromdmd->drives[drive_letter - 'A'];

		/* Zero the work buffers */
		memset(pbuf, 0, sizeof(pbuf));
		memset(dbuf, 0, sizeof(dbuf));

		/* Parameters */
		pbuf[0] = 0x00;
		pbuf[1] = drive_letter - 'A';

		/* Unlock */
		rc =	DosDevIOCtl(
					-1,					// ioctl handle
					0x08,				// category
					0x40,				// function
					pbuf,				// pParams
					sizeof(pbuf),		// cbParmLenMax
					&cbParam,			// pcbParmLen
					dbuf,				// pData
					sizeof(dbuf),		// cbDataLenMax
					&cbData				// pcbDataLen
				);

		/* Set lock status for device on success */
		drive->traystat_ex = rc ? drive->traystat_ex : (ULONG) ((USHORT*) dbuf)[0];

	} while (0);

	if (bShowFunc) printf("<< %s::%s status:0x%08x, rc:%d\n", __FILE__, __FUNCTION__, drive ? drive->traystat_ex : 0xffffffff, rc);
	return rc;
}

/*****************************************************************************\
* Eject a medium from a removable device                                      *
* --------------------------------------------------------------------------- *
* Devices are accessed by their drive letter.                                 *
* This opens the tray so the media can be taken out or replaced.              *
* For this function to work, the device must not be locked.                   *
*                                                                             *
* Note that this is not an 'os2cdrom.dmd' specific DosDevIOCtl call but a     *
* regular DosDevIOCtl call.                                                   *
*                                                                             *
* There also seems to be a way to close a tray, if supported by the device.   *
\*****************************************************************************/
APIRET	dmd_drive_media_eject(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter) {
	//! Hangs hard with NULL pointers
	APIRET	rc = -123;
	struct DRIVE	*drive = NULL;
	CHAR	pbuf[512];
	CHAR	dbuf[512];
	ULONG	cbParam = 0;
	ULONG	cbData = 0;

	if (bShowFunc) printf(">> %s::%s drive_letter:'%c'\n", __FILE__, __FUNCTION__, drive_letter);

	/* A do-block with mutiple exit points */
	do {
		//~ break;

		/* Check for NULL pointer */
		if (os2cdromdmd == NULL) break;

		/* Check for valid drive letter */
		if (drive_letter < 'A' || drive_letter > 'Z') break;

		/* Compose pointer to drive information */
		drive = &os2cdromdmd->drives[drive_letter - 'A'];

		/* Zero the work buffers */
		memset(pbuf, 0, sizeof(pbuf));
		memset(dbuf, 0, sizeof(dbuf));

		/* Parameters */
		pbuf[0] = 0x02;
		pbuf[1] = drive_letter - 'A';

		/* Eject */
		rc =	DosDevIOCtl(
					drive->handle,		// ioctl handle
					0x08,				// category
					0x40,				// function
					pbuf,				// pParams
					sizeof(pbuf),		// cbParmLenMax
					&cbParam,			// pcbParmLen
					dbuf,				// pData
					sizeof(dbuf),		// cbDataLenMax
					&cbData				// pcbDataLen
				);

		/* Set lock status for device on success */
		drive->traystat_ex = rc ? drive->traystat_ex : (ULONG) ((USHORT*) dbuf)[0];

	} while (0);

	if (bShowFunc) printf("<< %s::%s status:0x%08x, rc:%d\n", __FILE__, __FUNCTION__, drive ? drive->traystat_ex : 0xffffffff, rc);
	return rc;
}

/*****************************************************************************\
* Blank media (fast)                                                          *
* --------------------------------------------------------------------------- *
* Devices are accessed by their drive letter.                                 *
* This blanks the media in the drive.                                         *
* It only seems to work for CDRW media, DVDRW media return rc=87.             *
*                                                                             *
* Invoking blank a second time does not immediately return and the system     *
* queue is locked. When the first blank is finished, the scond blank is       *
* started and the system queue is responsive again.                           *
*                                                                             *
* Wonder how such multiple blank invocations work when using threads.         *
\*****************************************************************************/
APIRET	dmd_drive_media_blank(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter) {
	APIRET	rc = -123;
	struct DRIVE	*drive = NULL;
	CHAR	pbuf[512];
	CHAR	dbuf[512];
	ULONG	cbParam = 0;
	ULONG	cbData = 0;

	if (bShowFunc) printf(">> %s::%s drive_letter:'%c'\n", __FILE__, __FUNCTION__, drive_letter);

	/* A do-block with mutiple exit points */
	do {
		//~ break;

		/* Check for NULL pointer */
		if (os2cdromdmd == NULL) break;

		/* Check for valid drive letter */
		if (drive_letter < 'A' || drive_letter > 'Z') break;

		/* Compose pointer to drive information */
		drive = &os2cdromdmd->drives[drive_letter - 'A'];
		printf("drive->handle:0x%08x\n", drive->handle);

		/* Zero the work buffers */
		memset(pbuf, 0, sizeof(pbuf));
		memset(dbuf, 0, sizeof(dbuf));

		/* Parameters */
		pbuf[0] = 0x02;

		/* Blank a Medium (minimal/fast) */
		rc =	DosDevIOCtl(
					drive->handle,		// ioctl handle
					0x08,				// category
					0x46,				// function
					pbuf,				// pParams
					sizeof(pbuf),		// cbParmLenMax
					&cbParam,			// pcbParmLen
					dbuf,				// pData
					sizeof(dbuf),		// cbDataLenMax
					&cbData				// pcbDataLen
				);

		/* Update blank status */
		drive->blank_status = (ULONG) ((USHORT*) dbuf)[0];

	} while (0);

	if (bShowFunc) printf("<< %s::%s status:0x%08x, rc:%d\n", __FILE__, __FUNCTION__, drive ? drive->blank_status : 0xffffffff, rc);
	return rc;
}

/*****************************************************************************\
* Blank media (full)                                                          *
* --------------------------------------------------------------------------- *
* Devices are accessed by their drive letter.                                 *
* This blanks the media in the drive.                                         *
* It only seems to work for CDRW media, DVDRW media return rc=87.             *
*                                                                             *
* Invoking blank a second time does not immediately return and the system     *
* queue is locked. When the first blank is finished, the scond blank is       *
* started and the system queue is responsive again.                           *
*                                                                             *
* Wonder how such multiple blank invocations work when using threads.         *
\*****************************************************************************/
APIRET	dmd_drive_media_blank_full(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter) {
	APIRET	rc = -123;
	struct DRIVE	*drive = NULL;
	CHAR	pbuf[512];
	CHAR	dbuf[512];
	ULONG	cbParam = 0;
	ULONG	cbData = 0;

	if (bShowFunc) printf(">> %s::%s drive_letter:'%c'\n", __FILE__, __FUNCTION__, drive_letter);

	/* A do-block with mutiple exit points */
	do {
		//~ break;

		/* Check for NULL pointer */
		if (os2cdromdmd == NULL) break;

		/* Check for valid drive letter */
		if (drive_letter < 'A' || drive_letter > 'Z') break;

		/* Compose pointer to drive information */
		drive = &os2cdromdmd->drives[drive_letter - 'A'];

		/* Zero the work buffers */
		memset(pbuf, 0, sizeof(pbuf));
		memset(dbuf, 0, sizeof(dbuf));

		/* Parameters */
		pbuf[0] = 0x00;

		/* Blank a Medium (minimal/fast) */
		rc =	DosDevIOCtl(
					drive->handle,		// ioctl handle
					0x08,				// category
					0x46,				// function
					pbuf,				// pParams
					sizeof(pbuf),		// cbParmLenMax
					&cbParam,			// pcbParmLen
					dbuf,				// pData
					sizeof(dbuf),		// cbDataLenMax
					&cbData				// pcbDataLen
				);

		/* Update blank status */
		drive->blank_status = (ULONG) ((USHORT*) dbuf)[0];

	} while (0);

	if (bShowFunc) printf("<< %s::%s status:0x%08x, rc:%d\n", __FILE__, __FUNCTION__, drive ? drive->blank_status : 0xffffffff, rc);
	return rc;
}

/*****************************************************************************\
* Cancel blanking (does not seem to work)                                     *
* --------------------------------------------------------------------------- *
* Devices are accessed by their drive letter.                                 *
* This should cancel a blanking process in progress.                          *
* But it just blocks for some time and then returns with rc=0.                *
* Blanking continues however and the percentage blanked still increases.      *
\*****************************************************************************/
APIRET	dmd_drive_media_blank_cancel(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter) {
	APIRET	rc = -123;
	struct DRIVE	*drive = NULL;
	CHAR	pbuf[512];
	CHAR	dbuf[512];
	ULONG	cbParam = 0;
	ULONG	cbData = 0;

	if (bShowFunc) printf(">> %s::%s drive_letter:'%c'\n", __FILE__, __FUNCTION__, drive_letter);

	/* A do-block with mutiple exit points */
	do {
		//~ break;

		/* Check for NULL pointer */
		if (os2cdromdmd == NULL) break;

		/* Check for valid drive letter */
		if (drive_letter < 'A' || drive_letter > 'Z') break;

		/* Compose pointer to drive information */
		drive = &os2cdromdmd->drives[drive_letter - 'A'];

		/* Zero the work buffers */
		memset(pbuf, 0, sizeof(pbuf));
		memset(dbuf, 0, sizeof(dbuf));

		/* Parameters */
		pbuf[0] = 0x01;

		/* Blank a Medium (minimal/fast) */
		rc =	DosDevIOCtl(
					drive->handle,		// ioctl handle
					0x08,				// category
					0x45,				// function
					pbuf,				// pParams
					sizeof(pbuf),		// cbParmLenMax
					&cbParam,			// pcbParmLen
					dbuf,				// pData
					sizeof(dbuf),		// cbDataLenMax
					&cbData				// pcbDataLen
				);

		/* Update blank status */
		drive->blank_status = (ULONG) ((USHORT*) dbuf)[0];
		DumpPara((PCHAR) dbuf);
		printf("\n");

	} while (0);

	if (bShowFunc) printf("<< %s::%s status:0x%08x, rc:%d\n", __FILE__, __FUNCTION__, drive ? drive->blank_status : 0xffffffff, rc);
	return rc;
}

/*****************************************************************************\
* Get blanking progress                                                       *
* --------------------------------------------------------------------------- *
* Devices are accessed by their drive letter.                                 *
* This queries the status of a blanking operation in progress.                *
* It only seems to work for CDRW media, DVDRW media return rc=87.             *
*                                                                             *
* If no blanking operation is in progress, rc=87 is returned.                 *
* Otherwise, the max value is 0x64 (100%), depending on the time of query.    *
* When blanking is finished, rc=87 is returned with a status 0f 0.            *
\*****************************************************************************/
APIRET	dmd_drive_media_get_blank_status(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter) {
	APIRET	rc = -123;
	struct DRIVE	*drive = NULL;
	CHAR	pbuf[512];
	CHAR	dbuf[512];
	ULONG	cbParam = 0;
	ULONG	cbData = 0;

	if (bShowFunc) printf(">> %s::%s drive_letter:'%c'\n", __FILE__, __FUNCTION__, drive_letter);

	/* A do-block with mutiple exit points */
	do {
		//~ break;

		/* Check for NULL pointer */
		if (os2cdromdmd == NULL) break;

		/* Check for valid drive letter */
		if (drive_letter < 'A' || drive_letter > 'Z') break;

		/* Compose pointer to drive information */
		drive = &os2cdromdmd->drives[drive_letter - 'A'];

		/* Zero the work buffers */
		memset(pbuf, 0, sizeof(pbuf));
		memset(dbuf, 0, sizeof(dbuf));

		/* Parameters */
		pbuf[0] = 0x80;

		/* Blank a Medium (minimal/fast) */
		rc =	DosDevIOCtl(
					drive->handle,		// ioctl handle
					0x08,				// category
					0x46,				// function
					pbuf,				// pParams
					sizeof(pbuf),		// cbParmLenMax
					&cbParam,			// pcbParmLen
					dbuf,				// pData
					sizeof(dbuf),		// cbDataLenMax
					&cbData				// pcbDataLen
				);

		/* Update blank status */
		drive->blank_status = (ULONG) ((USHORT*) dbuf)[0];

	} while (0);

	if (bShowFunc) printf("<< %s::%s status:0x%08x, rc:%d\n", __FILE__, __FUNCTION__, drive ? drive->blank_status : 0xffffffff, rc);
	return rc;
}

/*****************************************************************************\
* Format and Verify                                                           *
* --------------------------------------------------------------------------- *
* Devices are accessed by their drive letter.                                 *
* This should be able to cancel a blanking process in progress.               *
* But it does not work (yet).                                                 *
\*****************************************************************************/
APIRET	dmd_drive_format_verify(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter) {
	APIRET	rc = -123;
	struct DRIVE	*drive = NULL;
	CHAR	pbuf[512];
	CHAR	dbuf[512];
	ULONG	cbParam = 0;
	ULONG	cbData = 0;

	if (bShowFunc) printf(">> %s::%s drive_letter:'%c'\n", __FILE__, __FUNCTION__, drive_letter);

	/* A do-block with mutiple exit points */
	do {
		//~ break;

		/* Check for NULL pointer */
		if (os2cdromdmd == NULL) break;

		/* Check for valid drive letter */
		if (drive_letter < 'A' || drive_letter > 'Z') break;

		/* Compose pointer to drive information */
		drive = &os2cdromdmd->drives[drive_letter - 'A'];

		/* Zero the work buffers */
		memset(pbuf, 0, sizeof(pbuf));
		memset(dbuf, 0, sizeof(dbuf));

		/* Parameters */
		pbuf[0] = 0x80;

		/* Format and Verify */
		rc =	DosDevIOCtl(
					drive->handle,		// ioctl handle
					0x08,				// category
					0x45,				// function
					pbuf,				// pParams
					sizeof(pbuf),		// cbParmLenMax
					&cbParam,			// pcbParmLen
					dbuf,				// pData
					sizeof(dbuf),		// cbDataLenMax
					&cbData				// pcbDataLen
				);

		DumpPara((PCHAR) dbuf);
		printf("\n");

	} while (0);

	if (bShowFunc) printf("<< %s::%s rc:%d\n", __FILE__, __FUNCTION__, rc);
	return rc;
}

/*****************************************************************************\
* Flush the buffers                                                           *
* --------------------------------------------------------------------------- *
* Devices are accessed by their drive letter.                                 *
* This flushes the buffers to ensure all data is written.                     *
* It only seems to work for CDRW media, DVDRW media return rc=87.             *
\*****************************************************************************/
APIRET	dmd_drive_flush_buffers(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter) {
	APIRET	rc = -123;
	struct DRIVE	*drive = NULL;
	CHAR	pbuf[512];
	CHAR	dbuf[512];
	ULONG	cbParam = 0;
	ULONG	cbData = 0;

	if (bShowFunc) printf(">> %s::%s drive_letter:'%c'\n", __FILE__, __FUNCTION__, drive_letter);

	/* A do-block with mutiple exit points */
	do {
		//~ break;

		/* Check for NULL pointer */
		if (os2cdromdmd == NULL) break;

		/* Check for valid drive letter */
		if (drive_letter < 'A' || drive_letter > 'Z') break;

		/* Compose pointer to drive information */
		drive = &os2cdromdmd->drives[drive_letter - 'A'];

		/* Zero the work buffers */
		memset(pbuf, 0, sizeof(pbuf));
		memset(dbuf, 0, sizeof(dbuf));

		/* Parameters */
		((ULONG*)pbuf)[0] = '10DC';		// 'CD01'

		/* Flush Buffers */
		rc =	DosDevIOCtl(
					drive->handle,		// ioctl handle
					0x80,				// category
					0x54,				// function
					pbuf,				// pParams
					sizeof(pbuf),		// cbParmLenMax
					&cbParam,			// pcbParmLen
					NULL,				// pData
					0,					// cbDataLenMax
					&cbData				// pcbDataLen
				);

		DumpPara((PCHAR) dbuf);
		printf("\n");

	} while (0);

	if (bShowFunc) printf("<< %s::%s rc:%d\n", __FILE__, __FUNCTION__, rc);
	return rc;
}

/*****************************************************************************\
* Query the media attributes                                                  *
* --------------------------------------------------------------------------- *
* Devices are accessed by their drive letter.                                 *
* This queries the attributes of media inserted.                              *
* These attributes can then be used to select the appropriate actions.        *
*                                                                             *
* This is an important function to tune further behaviour, but it is not used *
* in this build yet.                                                          *
\*****************************************************************************/
APIRET	dmd_drive_media_attributes(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter) {
	APIRET	rc = -123;
	struct DRIVE	*drive = NULL;
	CHAR	pbuf[512];
	CHAR	dbuf[512];
	ULONG	cbParam = 0;
	ULONG	cbData = 0;

	if (bShowFunc) printf(">> %s::%s drive_letter:'%c'\n", __FILE__, __FUNCTION__, drive_letter);

	/* A do-block with mutiple exit points */
	do {
		//~ break;

		/* Check for NULL pointer */
		if (os2cdromdmd == NULL) break;

		/* Check for valid drive letter */
		if (drive_letter < 'A' || drive_letter > 'Z') break;

		/* Compose pointer to drive information */
		drive = &os2cdromdmd->drives[drive_letter - 'A'];

		/* Zero the work buffers */
		memset(pbuf, 0, sizeof(pbuf));
		memset(dbuf, 0, sizeof(dbuf));

		/* Parameters */
		((ULONG*)pbuf)[0] = '10DC';		// 'CD01'

		/* Query Media Attributes */
		rc =	DosDevIOCtl(
					drive->handle,		// ioctl handle
					0x80,				// category
					0x64,				// function
					pbuf,				// pParams
					sizeof(pbuf),		// cbParmLenMax
					&cbParam,			// pcbParmLen
					dbuf,				// pData
					sizeof(dbuf),		// cbDataLenMax
					&cbData				// pcbDataLen
				);

		DumpPara((PCHAR) dbuf);
		printf("\n");

	} while (0);

	if (bShowFunc) printf("<< %s::%s rc:%d\n", __FILE__, __FUNCTION__, rc);
	return rc;
}

/*****************************************************************************\
* Query Device Parameters                                                     *
* --------------------------------------------------------------------------- *
* Devices are accessed by their drive letter.                                 *
* This queries the parameters of a device.                                    *
\*****************************************************************************/
APIRET	dmd_drive_query_device_params(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter) {
	APIRET	rc = -123;
	struct DRIVE	*drive = NULL;
	CHAR	pbuf[512];
	CHAR	dbuf[512];
	ULONG	cbParam = 0;
	ULONG	cbData = 0;

	if (bShowFunc) printf(">> %s::%s drive_letter:'%c'\n", __FILE__, __FUNCTION__, drive_letter);

	/* A do-block with mutiple exit points */
	do {
		//~ break;

		/* Check for NULL pointer */
		if (os2cdromdmd == NULL) break;

		/* Check for valid drive letter */
		if (drive_letter < 'A' || drive_letter > 'Z') break;

		/* Compose pointer to drive information */
		drive = &os2cdromdmd->drives[drive_letter - 'A'];

		/* Zero the work buffers */
		memset(pbuf, 0, sizeof(pbuf));
		memset(dbuf, 0, sizeof(dbuf));

		/* Parameters */
		pbuf[0] = 0x00;					// 0x00 can use -1 handle
		pbuf[1] = drive_letter - 'A';

		/* Query Device Parameters */
		rc =	DosDevIOCtl(
					-1,					// ioctl handle
					0x08,				// category
					0x63,				// function
					pbuf,				// pParams
					sizeof(pbuf),		// cbParmLenMax
					&cbParam,			// pcbParmLen
					dbuf,				// pData
					sizeof(dbuf),		// cbDataLenMax
					&cbData				// pcbDataLen
				);

		//~ DumpPara((PCHAR) dbuf);
		DumpBPB((BIOSPARAMETERBLOCK*) dbuf);
		printf("\n");

	} while (0);

	if (bShowFunc) printf("<< %s::%s rc:%d\n", __FILE__, __FUNCTION__, rc);
	return rc;
}

/*****************************************************************************\
* Query Device Status -- DOES NOT WORK YET                                    *
* --------------------------------------------------------------------------- *
* Devices are accessed by their drive letter.                                 *
* This queries the status of a device                                         *
\*****************************************************************************/
APIRET	dmd_drive_query_device_status(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter) {
	APIRET	rc = -123;
	struct DRIVE	*drive = NULL;
	CHAR	pbuf[512];
	CHAR	dbuf[512];
	ULONG	cbParam = 0;
	ULONG	cbData = 0;

	if (bShowFunc) printf(">> %s::%s drive_letter:'%c'\n", __FILE__, __FUNCTION__, drive_letter);

	/* A do-block with mutiple exit points */
	do {
		//~ break;

		/* Check for NULL pointer */
		if (os2cdromdmd == NULL) break;

		/* Check for valid drive letter */
		if (drive_letter < 'A' || drive_letter > 'Z') break;

		/* Compose pointer to drive information */
		drive = &os2cdromdmd->drives[drive_letter - 'A'];

		/* Zero the work buffers */
		memset(pbuf, 0, sizeof(pbuf));
		memset(dbuf, 0, sizeof(dbuf));

		/* Parameters */
		pbuf[0] = drive_letter - 'A';

		/* Query Device Status */
		rc =	DosDevIOCtl(
					os2cdromdmd->handle,	// ioctl handle
					0x82,					// category
					0x60,					// function
					pbuf,					// pParams
					sizeof(pbuf),			// cbParmLenMax
					&cbParam,				// pcbParmLen
					dbuf,					// pData
					sizeof(dbuf),			// cbDataLenMax
					&cbData					// pcbDataLen
				);

		DumpPara((PCHAR) dbuf);
		printf("\n");

	} while (0);

	if (bShowFunc) printf("<< %s::%s rc:%d\n", __FILE__, __FUNCTION__, rc);
	return rc;
}

/*****************************************************************************\
* Query Extended Device Status -- DOES NOT WORK YET                           *
* --------------------------------------------------------------------------- *
* Devices are accessed by their drive letter.                                 *
* This queries the extended status of a device.                               *
\*****************************************************************************/
APIRET	dmd_drive_query_device_status_ex(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter) {
	APIRET	rc = -123;
	struct DRIVE	*drive = NULL;
	CHAR	pbuf[512];
	CHAR	dbuf[512];
	ULONG	cbParam = 0;
	ULONG	cbData = 0;

	if (bShowFunc) printf(">> %s::%s drive_letter:'%c'\n", __FILE__, __FUNCTION__, drive_letter);

	/* A do-block with mutiple exit points */
	do {
		//~ break;

		/* Check for NULL pointer */
		if (os2cdromdmd == NULL) break;

		/* Check for valid drive letter */
		if (drive_letter < 'A' || drive_letter > 'Z') break;

		/* Compose pointer to drive information */
		drive = &os2cdromdmd->drives[drive_letter - 'A'];

		/* Zero the work buffers */
		memset(pbuf, 0, sizeof(pbuf));
		memset(dbuf, 0, sizeof(dbuf));

		/* Parameters */
		pbuf[0] = drive_letter - 'A';

		/* Query Extended Device Status */
		rc =	DosDevIOCtl(
					os2cdromdmd->handle,	// ioctl handle
					0x82,					// category
					0x61,					// function
					pbuf,					// pParams
					sizeof(pbuf),			// cbParmLenMax
					&cbParam,				// pcbParmLen
					dbuf,					// pData
					sizeof(dbuf),			// cbDataLenMax
					&cbData					// pcbDataLen
				);

		/* On success, put the extended device status in the drive structure */
		drive->devstat_ex = rc ? drive->devstat_ex : ((ULONG*) dbuf)[0];

		//~ DumpPara((PCHAR) dbuf);
		//~ printf("\n");

	} while (0);

	if (bShowFunc) printf("<< %s::%s rc:%d\n", __FILE__, __FUNCTION__, rc);
	return rc;
}

/*****************************************************************************\
* Read Data from a device -- CURRENTLY DISABLED                               *
* --------------------------------------------------------------------------- *
* Devices are accessed by their drive letter.                                 *
* This reads data from a device.                                              *
\*****************************************************************************/
APIRET	dmd_drive_read_data(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter) {
	APIRET	rc = -123;
	struct DRIVE	*drive = NULL;
	CHAR	pbuf[512];
	CHAR	dbuf[512];
	ULONG	cbParam = 0;
	ULONG	cbData = 0;

	if (bShowFunc) printf(">> %s::%s drive_letter:'%c'\n", __FILE__, __FUNCTION__, drive_letter);

	/* A do-block with mutiple exit points */
	do {
		break;

		/* Check for NULL pointer */
		if (os2cdromdmd == NULL) break;

		/* Check for valid drive letter */
		if (drive_letter < 'A' || drive_letter > 'Z') break;

		/* Compose pointer to drive information */
		drive = &os2cdromdmd->drives[drive_letter - 'A'];

		/* Zero the work buffers */
		memset(pbuf, 0, sizeof(pbuf));
		memset(dbuf, 0, sizeof(dbuf));

		/* Parameters */
		pbuf[0] = 0x80;

		/* Read Data */
		rc =	DosDevIOCtl(
					drive->handle,		// ioctl handle
					0x80,				// category
					0x76,				// function
					pbuf,				// pParams
					sizeof(pbuf),		// cbParmLenMax
					&cbParam,			// pcbParmLen
					dbuf,				// pData
					sizeof(dbuf),		// cbDataLenMax
					&cbData				// pcbDataLen
				);

		DumpPara((PCHAR) dbuf);
		printf("\n");

	} while (0);

	if (bShowFunc) printf("<< %s::%s rc:%d\n", __FILE__, __FUNCTION__, rc);
	return rc;
}

/*****************************************************************************\
* Write Data to a device -- CURRENTLY DISABLED                                *
* --------------------------------------------------------------------------- *
* Devices are accessed by their drive letter.                                 *
* This writes data to a device.                                               *
\*****************************************************************************/
APIRET	dmd_drive_write_data(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter) {
	APIRET	rc = -123;
	struct DRIVE	*drive = NULL;
	CHAR	pbuf[512];
	CHAR	dbuf[512];
	ULONG	cbParam = 0;
	ULONG	cbData = 0;

	if (bShowFunc) printf(">> %s::%s drive_letter:'%c'\n", __FILE__, __FUNCTION__, drive_letter);

	/* A do-block with mutiple exit points */
	do {
		break;

		/* Check for NULL pointer */
		if (os2cdromdmd == NULL) break;

		/* Check for valid drive letter */
		if (drive_letter < 'A' || drive_letter > 'Z') break;

		/* Compose pointer to drive information */
		drive = &os2cdromdmd->drives[drive_letter - 'A'];

		/* Zero the work buffers */
		memset(pbuf, 0, sizeof(pbuf));
		memset(dbuf, 0, sizeof(dbuf));

		/* Parameters */
		pbuf[0] = 0x80;

		/* Blank a Medium (minimal/fast) */
		rc =	DosDevIOCtl(
					drive->handle,		// ioctl handle
					0x80,				// category
					0x56,				// function
					pbuf,				// pParams
					sizeof(pbuf),		// cbParmLenMax
					&cbParam,			// pcbParmLen
					dbuf,				// pData
					sizeof(dbuf),		// cbDataLenMax
					&cbData				// pcbDataLen
				);

		DumpPara((PCHAR) dbuf);
		printf("\n");

	} while (0);

	if (bShowFunc) printf("<< %s::%s rc:%d\n", __FILE__, __FUNCTION__, rc);
	return rc;
}

/*****************************************************************************\
* Reset CDROM drive                                                           *
* --------------------------------------------------------------------------- *
* Devices are accessed by their drive letter.                                 *
* This function resets and reinitializes the drive.                           *
\*****************************************************************************/
APIRET	dmd_drive_cdrom_reset(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter) {
	APIRET	rc = -123;
	struct DRIVE	*drive = NULL;
	CHAR	pbuf[512];
	CHAR	dbuf[512];
	ULONG	cbParam = 0;
	ULONG	cbData = 0;

	if (bShowFunc) printf(">> %s::%s drive_letter:'%c'\n", __FILE__, __FUNCTION__, drive_letter);

	/* A do-block with mutiple exit points */
	do {
		//~ break;

		/* Check for NULL pointer */
		if (os2cdromdmd == NULL) break;

		/* Check for valid drive letter */
		if (drive_letter < 'A' || drive_letter > 'Z') break;

		/* Compose pointer to drive information */
		drive = &os2cdromdmd->drives[drive_letter - 'A'];

		/* Zero the work buffers */
		memset(pbuf, 0, sizeof(pbuf));
		memset(dbuf, 0, sizeof(dbuf));

		/* Parameters */
		*((ULONG*) &pbuf[0]) = '10DC';	// signature

		/* CDROM Reset */
		rc =	DosDevIOCtl(
					drive->handle,		// ioctl handle
					0x80,				// category
					0x40,				// function
					pbuf,				// pParams
					sizeof(pbuf),		// cbParmLenMax
					&cbParam,			// pcbParmLen
					NULL,				// pData
					0,					// cbDataLenMax
					&cbData				// pcbDataLen
				);

	} while (0);

	if (bShowFunc) printf("<< %s::%s rc:%d\n", __FILE__, __FUNCTION__, rc);
	return rc;
}

/*****************************************************************************\
* Eject media from  CDROM drive                                               *
* --------------------------------------------------------------------------- *
* Devices are accessed by their drive letter.                                 *
* This function ejects the media from the drive.                              *
\*****************************************************************************/
APIRET	dmd_drive_cdrom_eject(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter) {
	APIRET	rc = -123;
	struct DRIVE	*drive = NULL;
	CHAR	pbuf[512];
	CHAR	dbuf[512];
	ULONG	cbParam = 0;
	ULONG	cbData = 0;

	if (bShowFunc) printf(">> %s::%s drive_letter:'%c'\n", __FILE__, __FUNCTION__, drive_letter);

	/* A do-block with mutiple exit points */
	do {
		//~ break;

		/* Check for NULL pointer */
		if (os2cdromdmd == NULL) break;

		/* Check for valid drive letter */
		if (drive_letter < 'A' || drive_letter > 'Z') break;

		/* Compose pointer to drive information */
		drive = &os2cdromdmd->drives[drive_letter - 'A'];

		/* Zero the work buffers */
		memset(pbuf, 0, sizeof(pbuf));
		memset(dbuf, 0, sizeof(dbuf));

		/* Parameters */
		*((ULONG*) &pbuf[0]) = '10DC';	// signature

		/* CDROM Eject */
		rc =	DosDevIOCtl(
					drive->handle,		// ioctl handle
					0x80,				// category
					0x44,				// function
					pbuf,				// pParams
					sizeof(pbuf),		// cbParmLenMax
					&cbParam,			// pcbParmLen
					NULL,				// pData
					0,					// cbDataLenMax
					&cbData				// pcbDataLen
				);

	} while (0);

	if (bShowFunc) printf("<< %s::%s rc:%d\n", __FILE__, __FUNCTION__, rc);
	return rc;
}

/*****************************************************************************\
* Close CDROM tray                                                            *
* --------------------------------------------------------------------------- *
* Devices are accessed by their drive letter.                                 *
* This function closes the tray if supported by the device.                   *
\*****************************************************************************/
APIRET	dmd_drive_cdrom_close_tray(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter) {
	APIRET	rc = -123;
	struct DRIVE	*drive = NULL;
	CHAR	pbuf[512];
	CHAR	dbuf[512];
	ULONG	cbParam = 0;
	ULONG	cbData = 0;

	if (bShowFunc) printf(">> %s::%s drive_letter:'%c'\n", __FILE__, __FUNCTION__, drive_letter);

	/* A do-block with mutiple exit points */
	do {
		//~ break;

		/* Check for NULL pointer */
		if (os2cdromdmd == NULL) break;

		/* Check for valid drive letter */
		if (drive_letter < 'A' || drive_letter > 'Z') break;

		/* Compose pointer to drive information */
		drive = &os2cdromdmd->drives[drive_letter - 'A'];

		/* Zero the work buffers */
		memset(pbuf, 0, sizeof(pbuf));
		memset(dbuf, 0, sizeof(dbuf));

		/* Parameters */
		*((ULONG*) &pbuf[0]) = '10DC';	// signature

		/* CDROM Close Tray */
		rc =	DosDevIOCtl(
					drive->handle,		// ioctl handle
					0x80,				// category
					0x45,				// function
					pbuf,				// pParams
					sizeof(pbuf),		// cbParmLenMax
					&cbParam,			// pcbParmLen
					NULL,				// pData
					0,					// cbDataLenMax
					&cbData				// pcbDataLen
				);

	} while (0);

	if (bShowFunc) printf("<< %s::%s rc:%d\n", __FILE__, __FUNCTION__, rc);
	return rc;
}

/*****************************************************************************\
* Lock the CDROM tray                                                         *
* --------------------------------------------------------------------------- *
* Devices are accessed by their drive letter.                                 *
* This function locks the tray of the cdrom drive.                            *
\*****************************************************************************/
APIRET	dmd_drive_cdrom_lock_tray(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter) {
	APIRET	rc = -123;
	struct DRIVE	*drive = NULL;
	CHAR	pbuf[512];
	CHAR	dbuf[512];
	ULONG	cbParam = 0;
	ULONG	cbData = 0;

	if (bShowFunc) printf(">> %s::%s drive_letter:'%c'\n", __FILE__, __FUNCTION__, drive_letter);

	/* A do-block with mutiple exit points */
	do {
		//~ break;

		/* Check for NULL pointer */
		if (os2cdromdmd == NULL) break;

		/* Check for valid drive letter */
		if (drive_letter < 'A' || drive_letter > 'Z') break;

		/* Compose pointer to drive information */
		drive = &os2cdromdmd->drives[drive_letter - 'A'];

		/* Zero the work buffers */
		memset(pbuf, 0, sizeof(pbuf));
		memset(dbuf, 0, sizeof(dbuf));

		/* Parameters */
		*((ULONG*) &pbuf[0]) = '10DC';	// signature
		pbuf[4] = 0x01;					// lock

		/* CDROM Lock Tray */
		rc =	DosDevIOCtl(
					drive->handle,		// ioctl handle
					0x80,				// category
					0x46,				// function
					pbuf,				// pParams
					sizeof(pbuf),		// cbParmLenMax
					&cbParam,			// pcbParmLen
					NULL,				// pData
					0,					// cbDataLenMax
					&cbData				// pcbDataLen
				);

	} while (0);

	if (bShowFunc) printf("<< %s::%s rc:%d\n", __FILE__, __FUNCTION__, rc);
	return rc;
}

/*****************************************************************************\
* Unlock the CDROM tray                                                       *
* --------------------------------------------------------------------------- *
* Devices are accessed by their drive letter.                                 *
* This function unlocks the tray of the cdrom drive.                          *
\*****************************************************************************/
APIRET	dmd_drive_cdrom_unlock_tray(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter) {
	APIRET	rc = -123;
	struct DRIVE	*drive = NULL;
	CHAR	pbuf[512];
	CHAR	dbuf[512];
	ULONG	cbParam = 0;
	ULONG	cbData = 0;

	if (bShowFunc) printf(">> %s::%s drive_letter:'%c'\n", __FILE__, __FUNCTION__, drive_letter);

	/* A do-block with mutiple exit points */
	do {
		//~ break;

		/* Check for NULL pointer */
		if (os2cdromdmd == NULL) break;

		/* Check for valid drive letter */
		if (drive_letter < 'A' || drive_letter > 'Z') break;

		/* Compose pointer to drive information */
		drive = &os2cdromdmd->drives[drive_letter - 'A'];

		/* Zero the work buffers */
		memset(pbuf, 0, sizeof(pbuf));
		memset(dbuf, 0, sizeof(dbuf));

		/* Parameters */
		*((ULONG*) &pbuf[0]) = '10DC';	// signature
		pbuf[4] = 0x00;					// unlock

		/* CDROM Unlock Tray */
		rc =	DosDevIOCtl(
					drive->handle,		// ioctl handle
					0x80,				// category
					0x46,				// function
					pbuf,				// pParams
					sizeof(pbuf),		// cbParmLenMax
					&cbParam,			// pcbParmLen
					NULL,				// pData
					0,					// cbDataLenMax
					&cbData				// pcbDataLen
				);

	} while (0);

	if (bShowFunc) printf("<< %s::%s rc:%d\n", __FILE__, __FUNCTION__, rc);
	return rc;
}

/*****************************************************************************\
* Seek to a specific sector on the media in the CDROM drive                   *
* --------------------------------------------------------------------------- *
* Devices are accessed by their drive letter.                                 *
* This function seeks to a specific sector using LBA.                         *
\*****************************************************************************/
APIRET	dmd_drive_cdrom_seek(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter) {
	APIRET	rc = -123;
	struct DRIVE	*drive = NULL;
	CHAR	pbuf[512];
	CHAR	dbuf[512];
	ULONG	cbParam = 0;
	ULONG	cbData = 0;

	if (bShowFunc) printf(">> %s::%s drive_letter:'%c'\n", __FILE__, __FUNCTION__, drive_letter);

	/* A do-block with mutiple exit points */
	do {
		//~ break;

		/* Check for NULL pointer */
		if (os2cdromdmd == NULL) break;

		/* Check for valid drive letter */
		if (drive_letter < 'A' || drive_letter > 'Z') break;

		/* Compose pointer to drive information */
		drive = &os2cdromdmd->drives[drive_letter - 'A'];

		/* Zero the work buffers */
		memset(pbuf, 0, sizeof(pbuf));
		memset(dbuf, 0, sizeof(dbuf));

		/* Parameters */
		*((ULONG*) &pbuf[0]) = '10DC';	// signature
		pbuf[4] = 0x00;					// addressing mode, 0x00=LBA, 0x01=MSF
		*((ULONG*)&pbuf[5]) = 0;		// starting sector

		/* CDROM Seek */
		rc =	DosDevIOCtl(
					drive->handle,		// ioctl handle
					0x80,				// category
					0x50,				// function
					pbuf,				// pParams
					sizeof(pbuf),		// cbParmLenMax
					&cbParam,			// pcbParmLen
					NULL,				// pData
					0,					// cbDataLenMax
					&cbData				// pcbDataLen
				);

	} while (0);

	if (bShowFunc) printf("<< %s::%s rc:%d\n", __FILE__, __FUNCTION__, rc);
	return rc;
}

/*****************************************************************************\
* Query CDROM device status                                                   *
* --------------------------------------------------------------------------- *
* Devices are accessed by their drive letter.                                 *
* This function queries the device status of the cdrom drive.                 *
\*****************************************************************************/
APIRET	dmd_drive_cdrom_query_device_status(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter) {
	APIRET	rc = -123;
	struct DRIVE	*drive = NULL;
	CHAR	pbuf[512];
	CHAR	dbuf[512];
	ULONG	cbParam = 0;
	ULONG	cbData = 0;

	if (bShowFunc) printf(">> %s::%s drive_letter:'%c'\n", __FILE__, __FUNCTION__, drive_letter);

	/* A do-block with mutiple exit points */
	do {
		//~ break;

		/* Check for NULL pointer */
		if (os2cdromdmd == NULL) break;

		/* Check for valid drive letter */
		if (drive_letter < 'A' || drive_letter > 'Z') break;

		/* Compose pointer to drive information */
		drive = &os2cdromdmd->drives[drive_letter - 'A'];

		/* Zero the work buffers */
		memset(pbuf, 0, sizeof(pbuf));
		memset(dbuf, 0, sizeof(dbuf));

		/* Parameters */
		*((ULONG*) &pbuf[0]) = '10DC';	// signature

		/* CDROM Query Device Status */
		rc =	DosDevIOCtl(
					drive->handle,		// ioctl handle
					0x80,				// category
					0x60,				// function
					pbuf,				// pParams
					sizeof(pbuf),		// cbParmLenMax
					&cbParam,			// pcbParmLen
					dbuf,				// pData
					sizeof(dbuf),		// cbDataLenMax
					&cbData				// pcbDataLen
				);

		DumpPara((PCHAR) dbuf);
		printf("\n");

	} while (0);

	if (bShowFunc) printf("<< %s::%s rc:%d\n", __FILE__, __FUNCTION__, rc);
	return rc;
}

/*****************************************************************************\
* Query CDROM driver                                                          *
* --------------------------------------------------------------------------- *
* Devices are accessed by their drive letter.                                 *
* This function queries the driver for the cdrom drive.                       *
\*****************************************************************************/
APIRET	dmd_drive_cdrom_query_driver(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter) {
	APIRET	rc = -123;
	struct DRIVE	*drive = NULL;
	CHAR	pbuf[512];
	CHAR	dbuf[512];
	ULONG	cbParam = 0;
	ULONG	cbData = 0;

	if (bShowFunc) printf(">> %s::%s drive_letter:'%c'\n", __FILE__, __FUNCTION__, drive_letter);

	/* A do-block with mutiple exit points */
	do {
		//~ break;

		/* Check for NULL pointer */
		if (os2cdromdmd == NULL) break;

		/* Check for valid drive letter */
		if (drive_letter < 'A' || drive_letter > 'Z') break;

		/* Compose pointer to drive information */
		drive = &os2cdromdmd->drives[drive_letter - 'A'];

		/* Zero the work buffers */
		memset(pbuf, 0, sizeof(pbuf));
		memset(dbuf, 0, sizeof(dbuf));

		/* Parameters -- CD99 */
		*((ULONG*) &pbuf[0]) = '99DC';

		/* CDROM Query Driver */
		rc =	DosDevIOCtl(
					drive->handle,		// ioctl handle
					0x80,				// category
					0x61,				// function
					pbuf,				// pParams
					sizeof(pbuf),		// cbParmLenMax
					&cbParam,			// pcbParmLen
					dbuf,				// pData
					sizeof(dbuf),		// cbDataLenMax
					&cbData				// pcbDataLen
				);

		DumpPara((PCHAR) pbuf);
		printf("\n");
		DumpPara((PCHAR) dbuf);
		printf("\n");

	} while (0);

	if (bShowFunc) printf("<< %s::%s rc:%d\n", __FILE__, __FUNCTION__, rc);
	return rc;
}

/*****************************************************************************\
* Query the sector size of the CDROM drive                                    *
* --------------------------------------------------------------------------- *
* Devices are accessed by their drive letter.                                 *
* This function queries the sector size of the cdrom drive.                   *
\*****************************************************************************/
APIRET	dmd_drive_cdrom_query_secsize(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter) {
	APIRET	rc = -123;
	struct DRIVE	*drive = NULL;
	CHAR	pbuf[512];
	CHAR	dbuf[512];
	ULONG	cbParam = 0;
	ULONG	cbData = 0;

	if (bShowFunc) printf(">> %s::%s drive_letter:'%c'\n", __FILE__, __FUNCTION__, drive_letter);

	/* A do-block with mutiple exit points */
	do {
		//~ break;

		/* Check for NULL pointer */
		if (os2cdromdmd == NULL) break;

		/* Check for valid drive letter */
		if (drive_letter < 'A' || drive_letter > 'Z') break;

		/* Compose pointer to drive information */
		drive = &os2cdromdmd->drives[drive_letter - 'A'];

		/* Zero the work buffers */
		memset(pbuf, 0, sizeof(pbuf));
		memset(dbuf, 0, sizeof(dbuf));

		/* Parameters */
		*((ULONG*) &pbuf[0]) = '10DC';	// signature

		/* CDROM Query Sector Size */
		rc =	DosDevIOCtl(
					drive->handle,		// ioctl handle
					0x80,				// category
					0x63,				// function
					pbuf,				// pParams
					sizeof(pbuf),		// cbParmLenMax
					&cbParam,			// pcbParmLen
					dbuf,				// pData
					sizeof(dbuf),		// cbDataLenMax
					&cbData				// pcbDataLen
				);

		DumpPara((PCHAR) dbuf);
		printf("\n");

	} while (0);

	if (bShowFunc) printf("<< %s::%s rc:%d\n", __FILE__, __FUNCTION__, rc);
	return rc;
}

/*****************************************************************************\
* Query the head location of the CDROM drive                                  *
* --------------------------------------------------------------------------- *
* Devices are accessed by their drive letter.                                 *
* This function queries the head loation of the cdrom drive.                  *
\*****************************************************************************/
APIRET	dmd_drive_cdrom_query_headloc(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter) {
	APIRET	rc = -123;
	struct DRIVE	*drive = NULL;
	CHAR	pbuf[512];
	CHAR	dbuf[512];
	ULONG	cbParam = 0;
	ULONG	cbData = 0;

	if (bShowFunc) printf(">> %s::%s drive_letter:'%c'\n", __FILE__, __FUNCTION__, drive_letter);

	/* A do-block with mutiple exit points */
	do {
		//~ break;

		/* Check for NULL pointer */
		if (os2cdromdmd == NULL) break;

		/* Check for valid drive letter */
		if (drive_letter < 'A' || drive_letter > 'Z') break;

		/* Compose pointer to drive information */
		drive = &os2cdromdmd->drives[drive_letter - 'A'];

		/* Zero the work buffers */
		memset(pbuf, 0, sizeof(pbuf));
		memset(dbuf, 0, sizeof(dbuf));

		/* Parameters */
		*((ULONG*) &pbuf[0]) = '10DC';	// signature
		pbuf[4] = 0x00;					// addressing mode, 0x00=LBA, 0x01=MSF

		/* CDROM Query Head Location */
		rc =	DosDevIOCtl(
					drive->handle,		// ioctl handle
					0x80,				// category
					0x70,				// function
					pbuf,				// pParams
					sizeof(pbuf),		// cbParmLenMax
					&cbParam,			// pcbParmLen
					dbuf,				// pData
					sizeof(dbuf),		// cbDataLenMax
					&cbData				// pcbDataLen
				);

		DumpPara((PCHAR) dbuf);
		printf("\n");

	} while (0);

	if (bShowFunc) printf("<< %s::%s rc:%d\n", __FILE__, __FUNCTION__, rc);
	return rc;
}

/*****************************************************************************\
* Read a long sector from the CDROM drive                                     *
* --------------------------------------------------------------------------- *
* Devices are accessed by their drive letter.                                 *
* This function reads a long sector from the cdrom drive.                     *
\*****************************************************************************/
APIRET	dmd_drive_cdrom_read_long(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter) {
	APIRET	rc = -123;
	struct DRIVE	*drive = NULL;
	CHAR	pbuf[512];
	CHAR	dbuf[3172];
	ULONG	cbParam = 0;
	ULONG	cbData = 0;

	if (bShowFunc) printf(">> %s::%s drive_letter:'%c'\n", __FILE__, __FUNCTION__, drive_letter);

	/* A do-block with mutiple exit points */
	do {
		//~ break;

		/* Check for NULL pointer */
		if (os2cdromdmd == NULL) break;

		/* Check for valid drive letter */
		if (drive_letter < 'A' || drive_letter > 'Z') break;

		/* Compose pointer to drive information */
		drive = &os2cdromdmd->drives[drive_letter - 'A'];

		/* Zero the work buffers */
		memset(pbuf, 0, sizeof(pbuf));
		memset(dbuf, 0, sizeof(dbuf));

		/* Parameters */
		*((ULONG*) &pbuf[0]) = '10DC';	// signature
		pbuf[4] = 0x00;					// addressing mode, 0x00=LBA, 0x01=MSF
		*((USHORT*) &pbuf[5]) = 1;		// number of sectors to read
		pbuf[7] = 1;					// starting sector

		/* CDROM Query Volume Size */
		rc =	DosDevIOCtl(
					drive->handle,		// ioctl handle
					0x80,				// category
					0x72,				// function
					pbuf,				// pParams
					sizeof(pbuf),		// cbParmLenMax
					&cbParam,			// pcbParmLen
					dbuf,				// pData
					sizeof(dbuf),		// cbDataLenMax
					&cbData				// pcbDataLen
				);

		DumpMem((PCHAR) dbuf, 512/16);
		printf("\n");

	} while (0);

	if (bShowFunc) printf("<< %s::%s rc:%d\n", __FILE__, __FUNCTION__, rc);
	return rc;
}

/*****************************************************************************\
* Query the volume size of the media in the CDROM drive                       *
* --------------------------------------------------------------------------- *
* Devices are accessed by their drive letter.                                 *
* This function queries the volume size of the media in the cdrom drive.      *
\*****************************************************************************/
APIRET	dmd_drive_cdrom_query_volsize(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter) {
	APIRET	rc = -123;
	struct DRIVE	*drive = NULL;
	CHAR	pbuf[512];
	CHAR	dbuf[512];
	ULONG	cbParam = 0;
	ULONG	cbData = 0;

	if (bShowFunc) printf(">> %s::%s drive_letter:'%c'\n", __FILE__, __FUNCTION__, drive_letter);

	/* A do-block with mutiple exit points */
	do {
		//~ break;

		/* Check for NULL pointer */
		if (os2cdromdmd == NULL) break;

		/* Check for valid drive letter */
		if (drive_letter < 'A' || drive_letter > 'Z') break;

		/* Compose pointer to drive information */
		drive = &os2cdromdmd->drives[drive_letter - 'A'];

		/* Zero the work buffers */
		memset(pbuf, 0, sizeof(pbuf));
		memset(dbuf, 0, sizeof(dbuf));

		/* Parameters */
		*((ULONG*) &pbuf[0]) = '10DC';	// signature

		/* CDROM Query Volume Size */
		rc =	DosDevIOCtl(
					drive->handle,		// ioctl handle
					0x80,				// category
					0x78,				// function
					pbuf,				// pParams
					sizeof(pbuf),		// cbParmLenMax
					&cbParam,			// pcbParmLen
					dbuf,				// pData
					sizeof(dbuf),		// cbDataLenMax
					&cbData				// pcbDataLen
				);

		DumpPara((PCHAR) dbuf);
		printf("\n");

	} while (0);

	if (bShowFunc) printf("<< %s::%s rc:%d\n", __FILE__, __FUNCTION__, rc);
	return rc;
}

/*****************************************************************************\
* Query the product information of the media in the CDROM drive               *
* --------------------------------------------------------------------------- *
* Devices are accessed by their drive letter.                                 *
* This function queries the product information of the media present.         *
\*****************************************************************************/
APIRET	dmd_drive_cdrom_query_upc(struct OS2CDROMDMD *os2cdromdmd, CHAR drive_letter) {
	APIRET	rc = -123;
	struct DRIVE	*drive = NULL;
	CHAR	pbuf[512];
	CHAR	dbuf[512];
	ULONG	cbParam = 0;
	ULONG	cbData = 0;

	if (bShowFunc) printf(">> %s::%s drive_letter:'%c'\n", __FILE__, __FUNCTION__, drive_letter);

	/* A do-block with mutiple exit points */
	do {
		//~ break;

		/* Check for NULL pointer */
		if (os2cdromdmd == NULL) break;

		/* Check for valid drive letter */
		if (drive_letter < 'A' || drive_letter > 'Z') break;

		/* Compose pointer to drive information */
		drive = &os2cdromdmd->drives[drive_letter - 'A'];

		/* Zero the work buffers */
		memset(pbuf, 0, sizeof(pbuf));
		memset(dbuf, 0, sizeof(dbuf));

		/* Parameters */
		*((ULONG*) &pbuf[0]) = '10DC';	// signature

		/* CDROM Query Product Code */
		rc =	DosDevIOCtl(
					drive->handle,		// ioctl handle
					0x80,				// category
					0x79,				// function
					pbuf,				// pParams
					sizeof(pbuf),		// cbParmLenMax
					&cbParam,			// pcbParmLen
					dbuf,				// pData
					sizeof(dbuf),		// cbDataLenMax
					&cbData				// pcbDataLen
				);

		DumpPara((PCHAR) dbuf);
		printf("\n");

	} while (0);

	if (bShowFunc) printf("<< %s::%s rc:%d\n", __FILE__, __FUNCTION__, rc);
	return rc;
}


/* ######################################################################### */
/* ############################ TEST FUNCTIONS ############################# */
/* ######################################################################### */

/*
// Do some tests on the dmd function wrappers.
// This returns rc != 0, forcing open_driver() to fail.
*/
APIRET	DmdDoTests(struct OS2CDROMDMD *os2cdromdmd) {
	APIRET	rc = -123;
	CHAR test_drive = 0;
	struct DRIVE *drive = NULL;

	if (bShowFunc) printf(">> %s::%s\n", __FILE__, __FUNCTION__);

	/* A do-block with mutiple exit points */
	do {
		//~ break;

		/* Check for NULL pointer */
		if (os2cdromdmd == NULL) break;

		/* The first 'os2cdromdmd' handled drive is our test drive */
		test_drive = os2cdromdmd->first_drive + 'A';

		/* The second 'os2cdromdmd' handled drive is our test drive */
		//~ test_drive = os2cdromdmd->first_drive + 'A' + 1;

		/* Check for valid drive letter */
		if (test_drive < 'A' || test_drive > 'Z') break;

		/* Compose pointer to drive information */
		drive = &os2cdromdmd->drives[test_drive - 'A'];

		/* Print first drive handled and number of drives handled */
		printf(
			"first_drive:%02x, drive_count:%d\n",
			os2cdromdmd->first_drive,
			os2cdromdmd->drive_count
		);

		/* Open drive as DASD */
		rc = dmd_drive_open(os2cdromdmd, test_drive);
		printf(
			"letter:'%c', drive_handle:0x%08x, locked:%d\n",
			(CHAR) drive->letter,
			(HFILE) drive->handle,
			(BOOL) drive->locked
		);

		/* Open as DASD again -- no error */
		rc = dmd_drive_open(os2cdromdmd, test_drive);
		printf(
			"letter:'%c', drive_handle:0x%08x, locked:%d\n",
			(CHAR) drive->letter,
			(HFILE) drive->handle,
			(BOOL) drive->locked
		);

		/* Lock */
		rc = dmd_drive_lock(os2cdromdmd, test_drive);
		printf(
			"letter:'%c', drive_handle:0x%08x, locked:%d\n",
			(CHAR) drive->letter,
			(HFILE) drive->handle,
			(BOOL) drive->locked
		);

		/* Lock again -- no error, not nested */
		rc = dmd_drive_lock(os2cdromdmd, test_drive);
		printf(
			"letter:'%c', drive_handle:0x%08x, locked:%d\n",
			(CHAR) drive->letter,
			(HFILE) drive->handle,
			(BOOL) drive->locked
		);

		/* Redetermine media */
		rc = dmd_drive_redetermine_media(os2cdromdmd, test_drive);
		printf(
			"letter:'%c', drive_handle:0x%08x, locked:%d\n",
			(CHAR) drive->letter,
			(HFILE) drive->handle,
			(BOOL) drive->locked
		);

		/* Unlock */
		rc = dmd_drive_unlock(os2cdromdmd, test_drive);
		printf(
			"letter:'%c', drive_handle:0x%08x, locked:%d\n",
			(CHAR) drive->letter,
			(HFILE) drive->handle,
			(BOOL) drive->locked
		);

		/* Unlock again -- no error */
		rc = dmd_drive_unlock(os2cdromdmd, test_drive);
		printf(
			"letter:'%c', drive_handle:0x%08x, locked:%d\n",
			(CHAR) drive->letter,
			(HFILE) drive->handle,
			(BOOL) drive->locked
		);

		/* Close */
		rc = dmd_drive_close(os2cdromdmd, test_drive);
		printf(
			"letter:'%c', drive_handle:0x%08x, locked:%d\n",
			(CHAR) drive->letter,
			(HFILE) drive->handle,
			(BOOL) drive->locked
		);

		/* Close again -- no error */
		rc = dmd_drive_close(os2cdromdmd, test_drive);
		printf(
			"letter:'%c', drive_handle:0x%08x, locked:%d\n",
			(CHAR) drive->letter,
			(HFILE) drive->handle,
			(BOOL) drive->locked
		);

	} while (0);

	if (bShowFunc) printf("<< %s::%s rc:%d\n", __FILE__, __FUNCTION__, rc);
	return rc;
}

/*
// Partially dump a SRB.
// Use -V on 'readcd' to dump from higher transport levels.
*/
void	DumpSRB(SRB* srb) {

	printf(">> %s::%s srb:0x%08x\n", __FILE__, __FUNCTION__, srb);

	/* Dump the SRB structure */
	printf(
		"\tcmd:%d\n"
		"\tstatus:%d\n"
		"\tha_num:%d\n"
		"\tflags:0x%02x\n"
		"## SRB_Inquiry ##\n"
		"\tinq.num_ha:%d\n"
		"\tinq.ha_target:%d\n"
		"## SRB_Device ##\n"
		"\tdev.target:%d\n"
		"\tdev.lun:%d\n"
		"\tdev.devtype:0x%02x\n"
		"## SRB_Command ##\n"
		"\tcmd.target:%d\n"
		"\tcmd.lun:%d\n"
		"\tcmd.data_len:%d\n"
		"\tcmd.sense_len:%d\n"
		"\tcmd.data_ptr:0x%08x\n"
		"\tcmd.link_ptr:0x%08x\n"
		"\tcmd.cdb_len:%d\n"
		"\tcmd.ha_status:%d\n"
		"\tcmd.target_status:%d\n"
		,
		srb->cmd,
		srb->status,
		srb->ha_num,
		(unsigned char) srb->flags,				// vac308 does not honor printf %02x when negative
		/* SRB_Inquiry */
		srb->u.inq.num_ha,
		srb->u.inq.ha_target,
		/* SRB_Device */
		srb->u.dev.target,
		srb->u.dev.lun,
		(unsigned char) srb->u.dev.devtype,		// vac308 does not honor printf %02x when negative
		/* SRB_Command */
		srb->u.cmd.target,
		srb->u.cmd.lun,
		srb->u.cmd.data_len,
		srb->u.cmd.sense_len,
		srb->u.cmd.data_ptr,
		srb->u.cmd.link_ptr,
		srb->u.cmd.cdb_len,
		srb->u.cmd.ha_status,
		srb->u.cmd.target_status
	);

	//~ printf("::::::::::::::::::::::::::::::: BEGIN SRB DUMP ::::::::::::::::::::::::::::::::\n");
	//~ DumpMem((PCHAR) srb, sizeof(SRB)/16 + 1);
	//~ printf(":::::::::::::::::::::::::::::::: END SRB DUMP :::::::::::::::::::::::::::::::::\n");

	/* Dump CDB (scsi-command) */
	printf("!! CDB -- ASPI HAS SENSE INFO APPENDED -- 4 paragraphs !!\n");
	DumpMem((PCHAR) &srb->u.cmd.cdb_st, 4);

	/* Dump data -- is this the returned data ? -- it traps !! */
	//~ if (srb->u.cmd.data_ptr && srb->u.cmd.data_len) {
		//~ printf("!! DATA_PTR !!\n");
		//~ DumpMem(srb->u.cmd.data_ptr, srb->u.cmd.data_len/16);
	//~ }

	printf("<< %s::%s\n", __FILE__, __FUNCTION__);
}

/*
// Dump a BPB.
*/
void	DumpBPB(BIOSPARAMETERBLOCK* bpb) {
	/* Array of Media Names */
	char*	medianames[16] = {
				"UNKNOWN-MEDIUM-0",		// 0
				"UNKNOWN-MEDIUM-1",		// 1
				"UNKNOWN-MEDIUM-2",		// 2
				"UNKNOWN-MEDIUM-3",		// 3
				"CD-R",					// 4
				"CD-ROM",				// 5
				"DVD-ROM",				// 6
				"DVD-RAM",				// 7
				"CD-RW",				// 8
				"DVD-R",				// 9
				"DVD-RW",				// 10
				"DVD+RW",				// 11
				"DDCD-ROM",				// 12
				"DDCD-R",				// 13
				"DDCD-RW",				// 14
				"DVD+R",				// 15
			};

	printf("usBytesPerSector   : %d\n", (unsigned) bpb->usBytesPerSector);
	printf("bSectorsPerCluster : %d\n", (unsigned) bpb->bSectorsPerCluster);
	//~ printf("usReservedSectors  : %d\n", (unsigned) bpb->usReservedSectors);
	//~ printf("cFATs              : %d\n", (unsigned) bpb->cFATs);
	//~ printf("cRootEntries       : %d\n", (unsigned) bpb->cRootEntries);
	printf("cSectors           : %d\n", (unsigned) bpb->cSectors);
	printf("bMedia             : %d,%d (%s)\n", (unsigned) bpb->bMedia, (unsigned) bpb->bMedia & 0x0f, medianames[bpb->bMedia & 0x0f]);
	//~ printf("usSectorsPerFAT    : %d\n", (unsigned) bpb->usSectorsPerFAT);
	printf("usSectorsPerTrack  : %d\n", (unsigned) bpb->usSectorsPerTrack);
	printf("cHeads             : %d\n", (unsigned) bpb->cHeads);
	printf("cHiddenSectors     : %d\n", (unsigned) bpb->cHiddenSectors);
	printf("cLargeSectors      : %d\n", (unsigned) bpb->cLargeSectors);
	printf("cCylinders         : %d\n", (unsigned) bpb->cCylinders);
	printf("bDeviceType        : %d\n", (unsigned) bpb->bDeviceType);
	printf("fsDeviceAttr       : %d\n", (unsigned) bpb->fsDeviceAttr);
}

/*
// Dump 16 bytes of memory.
*/
void	DumpPara(PCHAR para) {
	int	i;
	char c;

	/* Print the address */
	printf("%08X ", para);

	/* Print the paragraph in hex bytes */
	for (i=0; i<16; i++) {
		printf("%02x", (unsigned char) para[i]);	// vac308 does not honor printf %02x when negative
		if (i<15) printf("-");
	}
	printf(" |");
	/* Print the paragraph in acsii chars (if printable) */
	for (i=0; i<16; i++) {
		c = para[i];
		if (c>=0x20 && c<=0x7e) {
			printf("%c", c);
		}
		else {
			printf(".");
		}
	}
	printf("|");
}

/*
// Dump a number of paragraphs from memory.
*/
void	DumpMem(PCHAR mem, int c) {
	int i;
	for (i=0; i<c; i++) {
		DumpPara(mem+i*16);
		printf("\n");
	}
}


